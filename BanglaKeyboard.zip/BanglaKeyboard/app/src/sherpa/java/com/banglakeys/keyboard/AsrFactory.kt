package com.banglakeys.keyboard

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import java.io.File

fun asrSupported() = true

fun createAsr(): AsrEngine = SherpaAsr()

/** Bangla Zipformer transducer (non-streaming) through sherpa-onnx. Clips up to ~20 s, ~60 ms each on a fast CPU. */
class SherpaAsr : AsrEngine {
    private var rec: OfflineRecognizer? = null

    override fun load(dir: File): Boolean = try {
        val cfg = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
            modelConfig = OfflineModelConfig(
                transducer = OfflineTransducerModelConfig(
                    encoder = File(dir, "encoder.onnx").absolutePath,
                    decoder = File(dir, "decoder.onnx").absolutePath,
                    joiner = File(dir, "joiner.onnx").absolutePath
                ),
                tokens = File(dir, "tokens.txt").absolutePath,
                numThreads = 4
            ),
            decodingMethod = "greedy_search"
        )
        rec = OfflineRecognizer(config = cfg)
        true
    } catch (t: Throwable) { rec = null; false }

    override fun transcribe(pcm: FloatArray, sampleRate: Int): String {
        val r = rec ?: return ""
        return try {
            val s = r.createStream()
            s.acceptWaveform(pcm, sampleRate)
            r.decode(s)
            val text = r.getResult(s).text
            s.release()
            text.trim()
        } catch (t: Throwable) { "" }
    }

    override fun release() { try { rec?.release() } catch (t: Throwable) { }; rec = null }
}
