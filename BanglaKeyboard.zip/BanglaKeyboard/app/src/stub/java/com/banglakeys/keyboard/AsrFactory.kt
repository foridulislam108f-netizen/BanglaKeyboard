package com.banglakeys.keyboard

import java.io.File

/** Built when libs/sherpa-onnx.aar is missing: the app still works, offline engine is just unavailable. */
fun asrSupported() = false

fun createAsr(): AsrEngine = object : AsrEngine {
    override fun load(dir: File) = false
    override fun transcribe(pcm: FloatArray, sampleRate: Int) = ""
    override fun release() {}
}
