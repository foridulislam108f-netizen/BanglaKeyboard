package com.banglakeys.keyboard

import android.graphics.Typeface

/** Letter styles: English = Unicode styled letters (typed output), Bangla = typeface of the key labels. */
object LetterStyle {
    val en = listOf(
        "normal" to "Normal", "bold" to "Bold", "italic" to "Italic", "bolditalic" to "Bold Italic",
        "script" to "Script", "gothic" to "Gothic", "double" to "Double-struck", "mono" to "Monospace",
        "circled" to "Circled", "smallcaps" to "Small caps", "full" to "Fullwidth", "squared" to "Squared"
    )
    val bn = listOf(
        "normal" to "Normal", "bold" to "Bold", "serif" to "Serif", "serifbold" to "Serif Bold",
        "italic" to "Italic (বাঁকা)", "light" to "Light"
    )

    private const val SMALL = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"
    private fun cp(c: Int) = String(Character.toChars(c))

    fun apply(style: String, s: String): String {
        if (style.isEmpty() || style == "normal") return s
        val sb = StringBuilder()
        for (ch in s) sb.append(map(style, ch))
        return sb.toString()
    }

    private fun map(style: String, ch: Char): String {
        val up = ch in 'A'..'Z'
        if (!up && ch !in 'a'..'z') return ch.toString()
        val i = if (up) ch - 'A' else ch - 'a'
        return when (style) {
            "bold" -> cp((if (up) 0x1D400 else 0x1D41A) + i)
            "italic" -> if (ch == 'h') "ℎ" else cp((if (up) 0x1D434 else 0x1D44E) + i)
            "bolditalic" -> cp((if (up) 0x1D468 else 0x1D482) + i)
            "script" -> cp((if (up) 0x1D4D0 else 0x1D4EA) + i)
            "gothic" -> cp((if (up) 0x1D56C else 0x1D586) + i)
            "double" -> if (up) when (ch) {
                'C' -> "ℂ"; 'H' -> "ℍ"; 'N' -> "ℕ"; 'P' -> "ℙ"
                'Q' -> "ℚ"; 'R' -> "ℝ"; 'Z' -> "ℤ"; else -> cp(0x1D538 + i)
            } else cp(0x1D552 + i)
            "mono" -> cp((if (up) 0x1D670 else 0x1D68A) + i)
            "circled" -> ((if (up) 0x24B6 else 0x24D0) + i).toChar().toString()
            "smallcaps" -> if (up) ch.toString() else SMALL[i].toString()
            "full" -> ((if (up) 0xFF21 else 0xFF41) + i).toChar().toString()
            "squared" -> cp(0x1F130 + i)
            else -> ch.toString()
        }
    }

    fun bnTypeface(style: String?): Typeface? = when (style) {
        "bold" -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        "serif" -> Typeface.SERIF
        "serifbold" -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        "italic" -> Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        else -> null
    }
}
