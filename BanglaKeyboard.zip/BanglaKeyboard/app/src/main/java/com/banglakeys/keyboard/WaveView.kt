package com.banglakeys.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** ভয়েস টাইপের সময় সাজেশন বারে দেখানো লাইভ সাউন্ড-ওয়েভ (গোল ডগার বার, আওয়াজের সাথে ডান থেকে বামে বয়ে যায়) */
class WaveView(c: Context) : View(c) {
    private val n = 15
    private val lv = FloatArray(n) { MIN }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    var color = 0xFF9E9E9E.toInt()
        set(v) { field = v; invalidate() }

    /** v = SpeechRecognizer-এর onRmsChanged মান (প্রায় -2 .. 10) */
    fun push(v: Float) {
        val x = ((v + 2f) / 12f).coerceIn(0f, 1f)
        System.arraycopy(lv, 1, lv, 0, n - 1)
        lv[n - 1] = MIN + (1f - MIN) * x
        invalidate()
    }

    fun reset() { java.util.Arrays.fill(lv, MIN); invalidate() }

    override fun hasOverlappingRendering() = false

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val slot = w / n
        val bw = slot * 0.5f
        p.color = color
        for (i in 0 until n) {
            val bh = h * lv[i]
            val cx = slot * (i + 0.5f)
            r.set(cx - bw / 2, (h - bh) / 2, cx + bw / 2, (h + bh) / 2)
            canvas.drawRoundRect(r, bw / 2, bw / 2, p)
        }
    }

    companion object { private const val MIN = 0.14f }
}
