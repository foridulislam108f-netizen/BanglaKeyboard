package com.banglakeys.keyboard

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Checks the latest GitHub Release of this repo and tells if it is newer than the installed version. */
object UpdateChecker {
    class Result(
        val newer: Boolean,
        val tag: String = "",
        val url: String = "",
        val notes: String = "",
        val error: String? = null
    )

    fun check(done: (Result) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val repo = BuildConfig.GH_REPO
        if (repo.isBlank()) { main.post { done(Result(false, error = "norepo")) }; return }
        Thread {
            val r = try {
                val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                if (c.responseCode != 200) Result(false, error = "http")
                else {
                    val j = JSONObject(c.inputStream.bufferedReader().readText())
                    val tag = j.optString("tag_name")
                    var url = j.optString("html_url")
                    val a = j.optJSONArray("assets")
                    if (a != null) for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        if (o.optString("name").endsWith(".apk")) { url = o.optString("browser_download_url"); break }
                    }
                    Result(isNewer(tag, BuildConfig.VERSION_NAME), tag, url, j.optString("body"))
                }
            } catch (e: Exception) { Result(false, error = "net") }
            main.post { done(r) }
        }.start()
    }

    private fun nums(s: String) = Regex("\\d+").findAll(s).map { it.value.toLong() }.toList()

    fun isNewer(tag: String, cur: String): Boolean {
        val a = nums(tag); val b = nums(cur)
        if (a.isEmpty()) return false
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0L }; val y = b.getOrElse(i) { 0L }
            if (x != y) return x > y
        }
        return false
    }
}
