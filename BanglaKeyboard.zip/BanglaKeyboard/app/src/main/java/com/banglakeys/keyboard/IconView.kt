package com.banglakeys.keyboard

import android.content.Context
import android.graphics.*
import android.view.View

/** Crisp line icons drawn with Canvas (no image files needed). */
class IconView(c: Context, var kind: String, var color: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val u = resources.displayMetrics.density          // 1 unit = 1dp, icon box = 24 x 24
        cv.save()
        cv.translate((width - 24 * u) / 2f, (height - 24 * u) / 2f)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * u
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.typeface = Typeface.DEFAULT_BOLD
        fun r(a: Float, b: Float, c2: Float, d: Float) = RectF(a * u, b * u, c2 * u, d * u)
        fun dot(x: Float, y: Float, rad: Float) {
            p.style = Paint.Style.FILL; cv.drawCircle(x * u, y * u, rad * u, p); p.style = Paint.Style.STROKE
        }
        when (kind) {
            "grid" -> {
                p.style = Paint.Style.FILL
                for (i in 0..1) for (j in 0..1) {
                    val x = 3f + 10.5f * i; val y = 3f + 10.5f * j
                    cv.drawRoundRect(r(x, y, x + 7.5f, y + 7.5f), 2.2f * u, 2.2f * u, p)
                }
            }
            "clip" -> {
                cv.drawRoundRect(r(5f, 5f, 19f, 21f), 2.5f * u, 2.5f * u, p)
                cv.drawRoundRect(r(9f, 2.5f, 15f, 6.5f), 1.5f * u, 1.5f * u, p)
                cv.drawLine(8.5f * u, 12f * u, 15.5f * u, 12f * u, p)
                cv.drawLine(8.5f * u, 16f * u, 13.5f * u, 16f * u, p)
            }
            "emoji" -> {
                cv.drawCircle(12f * u, 12f * u, 9f * u, p)
                dot(9f, 10f, 1.3f); dot(15f, 10f, 1.3f)
                cv.drawArc(r(7f, 8f, 17f, 17f), 25f, 130f, false, p)
            }
            "sticker" -> {
                val path = Path()
                path.moveTo(7f * u, 3f * u); path.lineTo(17f * u, 3f * u)
                path.quadTo(21f * u, 3f * u, 21f * u, 7f * u); path.lineTo(21f * u, 13f * u)
                path.lineTo(13f * u, 21f * u); path.lineTo(7f * u, 21f * u)
                path.quadTo(3f * u, 21f * u, 3f * u, 17f * u); path.lineTo(3f * u, 7f * u)
                path.quadTo(3f * u, 3f * u, 7f * u, 3f * u)
                cv.drawPath(path, p)
                cv.drawPath(Path().also { it.moveTo(21f * u, 13f * u); it.lineTo(17f * u, 13f * u); it.quadTo(13f * u, 13f * u, 13f * u, 17f * u); it.lineTo(13f * u, 21f * u) }, p)
                dot(9f, 9.5f, 1.2f); dot(14f, 9.5f, 1.2f)
                cv.drawArc(r(7f, 8f, 16f, 15f), 25f, 120f, false, p)
            }
            "num" -> {
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = 11f * u
                cv.drawText("1 2", 12f * u, 11f * u, p)
                cv.drawText("3 4", 12f * u, 21.5f * u, p)
            }
            "lang" -> {
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = 15f * u
                cv.drawText("অ", 8f * u, 14f * u, p)
                p.textSize = 12f * u
                cv.drawText("A", 17f * u, 21f * u, p)
            }
            "gear" -> {
                p.strokeWidth = 3.2f * u
                p.strokeCap = Paint.Cap.BUTT
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val c1 = Math.cos(a).toFloat(); val s1 = Math.sin(a).toFloat()
                    cv.drawLine((12f + 7f * c1) * u, (12f + 7f * s1) * u, (12f + 10f * c1) * u, (12f + 10f * s1) * u, p)
                }
                p.strokeWidth = 2.4f * u
                cv.drawCircle(12f * u, 12f * u, 6.2f * u, p)
                p.strokeWidth = 2f * u
                cv.drawCircle(12f * u, 12f * u, 2.3f * u, p)
            }
            "mic" -> {
                p.style = Paint.Style.FILL
                cv.drawRoundRect(r(8.5f, 2.5f, 15.5f, 14f), 3.5f * u, 3.5f * u, p)
                p.style = Paint.Style.STROKE
                cv.drawArc(r(5.5f, 5.5f, 18.5f, 18.5f), 0f, 180f, false, p)
                cv.drawLine(12f * u, 18.5f * u, 12f * u, 21.5f * u, p)
                cv.drawLine(8.5f * u, 21.5f * u, 15.5f * u, 21.5f * u, p)
            }
        }
        cv.restore()
    }
}
