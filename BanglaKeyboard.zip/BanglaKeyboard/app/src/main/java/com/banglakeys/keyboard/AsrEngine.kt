package com.banglakeys.keyboard

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Offline speech engine (Bangla). Real implementation lives in src/sherpa, a harmless stub in src/stub. */
interface AsrEngine {
    fun load(dir: File): Boolean
    fun transcribe(pcm: FloatArray, sampleRate: Int): String
    fun release()
}

/** Downloads / locates the Bangla Zipformer model (int8, ~71 MB). License: CC BY-SA 4.0 (SayedShaun/bangla-zipformer-onnx). */
object AsrModel {
    private const val BASE = "https://huggingface.co/SayedShaun/bangla-zipformer-onnx/resolve/main/"
    // remote path -> local file name
    private val FILES = listOf(
        "int8/encoder.onnx" to "encoder.onnx",
        "int8/decoder.onnx" to "decoder.onnx",
        "int8/joiner.onnx" to "joiner.onnx",
        "tokens.txt" to "tokens.txt"
    )

    fun dir(ctx: Context) = File(ctx.filesDir, "asr_bn")

    fun ready(ctx: Context): Boolean = FILES.all { File(dir(ctx), it.second).let { f -> f.exists() && f.length() > 0 } }

    /** Blocking. Call from a background thread. [progress] gets (fileIndex 1..4, percent of that file). Returns null on success, else an error text. */
    fun download(ctx: Context, progress: (Int, Int) -> Unit): String? {
        return try {
            val d = dir(ctx); d.mkdirs()
            for ((i, f) in FILES.withIndex()) {
                val out = File(d, f.second)
                if (out.exists() && out.length() > 0) { progress(i + 1, 100); continue }
                val tmp = File(d, f.second + ".part")
                var u = URL(BASE + f.first)
                var c = u.openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 30000
                c.instanceFollowRedirects = true
                var hops = 0
                while (c.responseCode in 301..308 && hops < 5) {      // follow redirects by hand (http<->https safe)
                    u = URL(c.getHeaderField("Location")); c.disconnect()
                    c = u.openConnection() as HttpURLConnection
                    c.connectTimeout = 20000; c.readTimeout = 30000; hops++
                }
                if (c.responseCode != 200) return "সার্ভার সাড়া দেয়নি (${c.responseCode})"
                val total = c.contentLengthLong
                c.inputStream.use { ins ->
                    FileOutputStream(tmp).use { os ->
                        val buf = ByteArray(64 * 1024); var got = 0L; var last = -1
                        while (true) {
                            val n = ins.read(buf); if (n < 0) break
                            os.write(buf, 0, n); got += n
                            if (total > 0) { val p = (got * 100 / total).toInt(); if (p != last) { last = p; progress(i + 1, p) } }
                        }
                    }
                }
                if (!tmp.renameTo(out)) return "ফাইল সংরক্ষণ করা যায়নি"
                progress(i + 1, 100)
            }
            null
        } catch (e: Exception) { "ডাউনলোড ব্যর্থ: ${e.message ?: e.javaClass.simpleName}" }
    }

    fun delete(ctx: Context) { dir(ctx).deleteRecursively() }
}
