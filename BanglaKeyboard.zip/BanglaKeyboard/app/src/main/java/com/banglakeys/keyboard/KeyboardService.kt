package com.banglakeys.keyboard

import android.content.*
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.*
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

class KeyboardService : InputMethodService() {

    private lateinit var prefs: SharedPreferences
    private var root: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())

    private var th = Themes.get("dark")
    private var keyH = 52
    private var fs = 1f
    private var gap = 2
    private var flat = false
    private var lang = "bn"          // bn | en
    private var mode = "bn"          // bn (classic) | bnp (phonetic) | en | sym
    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var tools = false
    private var panel = ""           // "" | emoji | sticker | clip
    private var lastBase: String? = null
    private val comp = StringBuilder()   // phonetic roman buffer

    private val letters = ArrayList<Pair<TextView, String>>()
    private var shiftView: TextView? = null
    private val karViews = ArrayList<TextView>()
    private val sug = ArrayList<TextView>()

    private val vowels = listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "এ", "ঐ", "ও", "ঔ")
    private val kars = listOf("", "\u09BE", "\u09BF", "\u09C0", "\u09C1", "\u09C2", "\u09C7", "\u09C8", "\u09CB", "\u09CC")
    private val bnRows = listOf(
        listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"),
        listOf("ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"),
        listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"),
        listOf("স", "হ", "\u09DC", "\u09DD", "\u09DF", "ৎ", "ং", "ঃ", "ঁ")
    )

    // ---------- live voice typing (text appears while you speak) ----------
    private var recognizer: android.speech.SpeechRecognizer? = null
    private var voiceOn = false
    private var micView: View? = null

    private val recListener = object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onPartialResults(r: Bundle?) {
            val t = r?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (t.isNotEmpty()) currentInputConnection?.setComposingText(t, 1)
        }

        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            val ic = currentInputConnection
            if (!t.isNullOrEmpty() && ic != null) ic.commitText("$t ", 1) else ic?.finishComposingText()
            lastBase = null
            if (voiceOn) h.postDelayed({ listenNow() }, 150)   // keep listening
        }

        override fun onError(e: Int) {
            currentInputConnection?.finishComposingText()
            if (!voiceOn) return
            when (e) {
                android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> h.postDelayed({ listenNow() }, 150)
                android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel(); h.postDelayed({ listenNow() }, 400)
                }
                android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stopVoice(); askMicPermission()
                }
                android.speech.SpeechRecognizer.ERROR_NETWORK,
                android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                android.speech.SpeechRecognizer.ERROR_SERVER -> {
                    stopVoice(); Toast.makeText(this@KeyboardService, "ইন্টারনেট চেক করুন", Toast.LENGTH_SHORT).show()
                }
                else -> { stopVoice(); Toast.makeText(this@KeyboardService, "ভয়েস টাইপ চালু করা যায়নি ($e)", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun askMicPermission() {
        startActivity(Intent(this, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun listenNow() {
        if (!voiceOn) return
        try {
            if (recognizer == null) {
                recognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(recListener)
            }
            val i = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, if (lang == "bn") "bn-BD" else "en-US")
                .putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(android.speech.RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            recognizer?.startListening(i)
        } catch (e: Exception) {
            stopVoice()
            Toast.makeText(this, "ভয়েস টাইপ পাওয়া যাচ্ছে না", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startVoice() {
        if (voiceOn) { stopVoice(); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            askMicPermission(); return
        }
        flush()
        voiceOn = true
        micView?.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(0xFFE53935.toInt()) }
        listenNow()
    }

    private fun stopVoice() {
        voiceOn = false
        h.removeCallbacksAndMessages(null)
        try { recognizer?.stopListening(); recognizer?.cancel() } catch (e: Exception) { }
        currentInputConnection?.finishComposingText()
        micView?.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(th.keyAlt) }
    }

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        Words.load(this)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            try {
                val t = cm.primaryClip?.getItemAt(0)?.text?.toString()
                if (!t.isNullOrBlank() && prefs.getBoolean("clipon", true)) pushList("clips", t, 20)
            } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        voiceOn = false
        try { recognizer?.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        root = r
        applyPrefs()
        mode = layoutFor(lang)
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        comp.setLength(0); lastBase = null; tools = false; panel = ""
        applyPrefs()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) "num" else layoutFor(lang)
        caps = false
        shift = mode == "en" && (currentInputConnection?.getTextBeforeCursor(1, 0)?.isEmpty() ?: false)
        build()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        if (voiceOn) stopVoice()
        super.onFinishInputView(finishingInput)
    }

    override fun onFinishInput() {
        comp.setLength(0)
        super.onFinishInput()
    }

    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) {
        super.onUpdateSelection(a, b, c, d, e, f)
        if (comp.isNotEmpty() && (e == -1 || f == -1)) comp.setLength(0)
        updateSuggestions()
    }

    private fun applyPrefs() {
        th = Themes.get(prefs.getString("theme", "dark") ?: "dark", prefs)
        keyH = prefs.getInt("keyh", 52)
        fs = prefs.getInt("fscale", 100) / 100f
        gap = prefs.getInt("gap", 2)
        flat = prefs.getBoolean("flat", false)
        lang = prefs.getString("lang", "bn") ?: "bn"
    }

    private fun layoutFor(l: String): String =
        if (l == "en") "en" else if (prefs.getString("bnlayout", "classic") == "phonetic") "bnp" else "bn"

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buzz() {
        if (prefs.getBoolean("vibrate", true)) root?.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun keyBg(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(th.radius).toFloat()
        if (th.stroke != 0) g.setStroke(dp(1), th.stroke)
        return g
    }

    private fun getList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("\u0001").filter { it.isNotEmpty() }

    private fun pushList(k: String, v: String, max: Int) {
        val l = getList(k).toMutableList()
        l.remove(v); l.add(0, v)
        prefs.edit().putString(k, l.take(max).joinToString("\u0001")).apply()
    }

    private fun addRecent(w: String) { if (w.length >= 2) pushList("recent", w, 40) }

    private fun key(
        label: String, w: Float = 1f, alt: Boolean = false, size: Float = 20f,
        long: (() -> Unit)? = null, hint: String? = null, tap: () -> Unit
    ): TextView {
        val t = HintTextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(th.text)
        t.textSize = size * th.scale * fs
        t.background = if (flat && !alt) null else keyBg(if (alt) th.keyAlt else th.key)
        if (hint != null && prefs.getBoolean("hints", true)) {
            t.hintText = hint; t.hintColor = th.dim; t.hintSize = dp(11).toFloat()
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        lp.setMargins(dp(gap), dp(3), dp(gap), dp(3))
        t.layoutParams = lp
        t.setOnClickListener { buzz(); tap() }
        val lg: (() -> Unit)? = long ?: (if (hint != null) ({ commit(hint) }) else null)
        if (lg != null) t.setOnLongClickListener { buzz(); lg(); true }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.alpha = 0.55f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
            }
            false
        }
        return t
    }

    private fun rowOf(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyH))
        for (x in v) l.addView(x)
        return l
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        return v
    }

    private fun backKey(w: Float): TextView {
        val t = key("⌫", w, true, 20f) { }
        val rep = object : Runnable {
            override fun run() { doBackspace(); h.postDelayed(this, 55) }
        }
        t.setOnClickListener(null)
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.alpha = 0.55f; buzz(); doBackspace(); h.postDelayed(rep, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; h.removeCallbacks(rep) }
            }
            true
        }
        return t
    }

    // ---------- build UI ----------
    private fun build() {
        val r = root ?: return
        r.removeAllViews(); letters.clear(); karViews.clear(); sug.clear(); shiftView = null
        r.orientation = LinearLayout.VERTICAL
        val g = th.grad
        r.background = if (g != null) GradientDrawable(GradientDrawable.Orientation.TL_BR, g)
        else GradientDrawable().also { it.setColor(th.bg) }
        r.setPadding(dp(3), dp(2), dp(3), dp(6))
        if (mode != "num") r.addView(topBar())
        if (panel.isNotEmpty()) {
            r.addView(panelView())
        } else {
            when (mode) {
                "bn" -> bnLayout(r)
                "sym" -> symLayout(r)
                "num" -> numLayout(r)
                else -> qwerty(r)
            }
            if (mode != "num") r.addView(bottomRow())
        }
        refreshKar(); refreshShift(); updateSuggestions()
    }

    private fun tbtn(label: String, w: Float = 0f, f: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label; t.textSize = 20f; t.gravity = Gravity.CENTER; t.setTextColor(th.text)
        t.layoutParams = if (w > 0f) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        else LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT)
        t.setOnClickListener { buzz(); f() }
        return t
    }

    private fun ibtn(kind: String, w: Float = 0f, f: () -> Unit): IconView {
        val v = IconView(this, kind, th.text)
        v.layoutParams = if (w > 0f) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        else LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT)
        v.setOnClickListener { buzz(); f() }
        v.setOnTouchListener { x, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> x.alpha = 0.5f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.alpha = 1f
            }
            false
        }
        return v
    }

    private fun topBar(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        if (tools) {
            l.addView(ibtn("grid", 1f) { tools = false; build() }.also { it.color = th.accent })
            l.addView(ibtn("clip", 1f) { panel = "clip"; tools = false; build() })
            l.addView(ibtn("emoji", 1f) { panel = "emoji"; tools = false; build() })
            l.addView(ibtn("sticker", 1f) { panel = "sticker"; tools = false; build() })
            l.addView(ibtn("num", 1f) { flush(); mode = "num"; tools = false; build() })
            l.addView(ibtn("lang", 1f) { toggleBnLayout() })
            l.addView(ibtn("gear", 1f) { openSettings() })
        } else {
            l.addView(ibtn("grid") { tools = true; build() })
            for (i in 0 until 3) {
                val t = TextView(this)
                t.gravity = Gravity.CENTER; t.textSize = 17f; t.setTextColor(th.text)
                t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END
                t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                t.setOnClickListener { pickSuggestion(t.text.toString()) }
                sug.add(t); l.addView(t)
            }
        }
        val mic = ibtn("mic") { startVoice() }
        micView = mic
        mic.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(if (voiceOn) 0xFFE53935.toInt() else th.keyAlt) }
        val mlp = LinearLayout.LayoutParams(dp(40), dp(40))
        mlp.setMargins(dp(4), 0, dp(4), 0)
        mic.layoutParams = mlp
        l.addView(mic)
        return l
    }

    private fun bnLayout(r: LinearLayout) {
        val kr = ArrayList<View>()
        for (i in 0 until 10) {
            val t = key("", 1f, false, 20f) { karTap(i) }
            t.setTextColor(th.dim)
            karViews.add(t); kr.add(t)
        }
        r.addView(rowOf(*kr.toTypedArray()))
        for (i in 0 until 3) r.addView(rowOf(*bnRows[i].map { bnKey(it) }.toTypedArray()))
        val last = ArrayList<View>()
        for (c in bnRows[3]) last.add(bnKey(c))
        last.add(backKey(1f))
        r.addView(rowOf(*last.toTypedArray()))
    }

    private fun bnKey(c: String): TextView {
        val isBase = c != "ং" && c != "ঃ" && c != "ঁ"
        return key(c, size = 22f) {
            commit(c)
            if (isBase) { lastBase = c; refreshKar() }
        }
    }

    private fun karLabel(i: Int): String { val b = lastBase; return if (b == null) vowels[i] else b + kars[i] }

    private fun refreshKar() { for (i in karViews.indices) karViews[i].text = karLabel(i) }

    private fun karTap(i: Int) {
        val ic = currentInputConnection ?: return
        val lab = karLabel(i)
        val b = lastBase
        if (b != null) ic.deleteSurroundingText(b.length, 0)
        ic.commitText(lab, 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun qwerty(r: LinearLayout) {
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val digits = "1234567890"
        r.addView(rowOf(*rows[0].mapIndexed { i, c -> letterKey(c, digits[i].toString()) }.toTypedArray()))
        val r2 = ArrayList<View>()
        r2.add(spacer(0.5f))
        for ((i, c) in rows[1].withIndex()) r2.add(letterKey(c, "@#\$%&-+()"[i].toString()))
        r2.add(spacer(0.5f))
        r.addView(rowOf(*r2.toTypedArray()))
        val r3 = ArrayList<View>()
        val sh = key("⇧", 1.5f, true, 22f) {
            val now = SystemClock.uptimeMillis()
            if (now - lastShiftTap < 350) { caps = true; shift = true }
            else if (caps) { caps = false; shift = false }
            else shift = !shift
            lastShiftTap = now
            refreshShift()
        }
        shiftView = sh
        r3.add(sh)
        for ((i, c) in rows[2].withIndex()) r3.add(letterKey(c, "*\"':;!?"[i].toString()))
        r3.add(backKey(1.5f))
        r.addView(rowOf(*r3.toTypedArray()))
    }

    private fun letterKey(c: Char, digit: String?): TextView {
        val lg: (() -> Unit)? = if (digit != null) ({ commit(digit) }) else null
        val t = key(c.toString(), 1f, false, 20f, null, digit) { typeLetter(c) }
        letters.add(Pair(t, c.toString()))
        return t
    }

    private fun typeLetter(c: Char) {
        val ch = if (shift) c.uppercaseChar() else c
        if (mode == "bnp") phon(ch.toString()) else commit(ch.toString())
        if (shift && !caps) { shift = false; refreshShift() }
    }

    private fun refreshShift() {
        for (p in letters) p.first.text = if (shift) p.second.uppercase() else p.second
        val s = shiftView ?: return
        val on = shift || caps
        s.background = keyBg(if (on) th.accent else th.keyAlt)
        s.setTextColor(if (on) th.onAccent else th.text)
        s.text = if (caps) "⇪" else "⇧"
    }

    private fun symLayout(r: LinearLayout) {
        val d = if (lang == "bn") "১২৩৪৫৬৭৮৯০" else "1234567890"
        r.addView(strRow(d))
        r.addView(strRow("@#\$%&-+()/"))
        val l = ArrayList<View>()
        for (ch in "=*\"':;!?।") l.add(key(ch.toString()) { commit(ch.toString()) })
        l.add(backKey(1f))
        r.addView(rowOf(*l.toTypedArray()))
    }

    private fun strRow(s: String): LinearLayout =
        rowOf(*s.map { ch -> key(ch.toString()) { commit(ch.toString()) } }.toTypedArray())

    private fun bottomRow(): LinearLayout {
        val sym = mode == "sym"
        val v = ArrayList<View>()
        v.add(key(if (sym) "ABC" else if (lang == "bn") "?১২৩" else "?123", 1.5f, true, 15f) {
            flush(); mode = if (sym) layoutFor(lang) else "sym"; build()
        })
        v.add(key("☺\n,", 1f, true, 14f, { panel = "emoji"; build() }) { commit(",") })
        v.add(key("🌐", 1f, false, 18f, { imePicker() }) { switchLang() })
        val label = when (mode) { "bn" -> "বাংলা"; "bnp" -> "বাংলা (ফোনেটিক)"; "en" -> "English"; else -> "" }
        v.add(key(label, if (mode == "bn") 3.2f else 4f, false, 14f, { imePicker() }) { onSpace() })
        if (mode == "bn") {
            v.add(key("\u25CC\u09CD", 1f, true, 18f, { commit("\u09CD\u09AF") }) { commit("\u09CD") })
        }
        val dot = if (lang == "bn") "।" else "."
        v.add(key(dot, 1f, true, 20f) { commit(dot) })
        val enter = key("⏎", 1.5f, false, 22f) { enterKey() }
        val ea = prefs.getBoolean("enteraccent", true)
        enter.background = keyBg(if (ea) th.accent else th.keyAlt)
        enter.setTextColor(if (ea) th.onAccent else th.text)
        v.add(enter)
        return rowOf(*v.toTypedArray())
    }

    // ---------- number pad ----------
    private fun nk(label: String, w: Float, tap: () -> Unit): TextView {
        val t = key(label, w, false, 26f, null, null, tap)
        t.background = null
        return t
    }

    private fun numRow(vararg v: View): LinearLayout {
        val l = rowOf(*v)
        l.layoutParams.height = dp(keyH + 10)
        return l
    }

    private fun divider(show: Boolean = true): View {
        val v = View(this)
        if (show) v.setBackgroundColor(th.dim)
        val lp = LinearLayout.LayoutParams(dp(2), ViewGroup.LayoutParams.MATCH_PARENT)
        lp.setMargins(dp(2), dp(14), dp(2), dp(14))
        v.layoutParams = lp
        return v
    }

    private fun numLayout(r: LinearLayout) {
        fun ch(s: String, w: Float = 1.2f) = nk(s, w) { commit(s) }
        r.addView(numRow(ch("+", 0.8f), divider(), ch("1"), ch("2"), ch("3"), ch("\u2260", 0.8f)))
        r.addView(numRow(ch("-", 0.8f), divider(), ch("4"), ch("5"), ch("6"), ch("=", 0.8f)))
        val bk = backKey(0.8f)
        bk.background = null
        r.addView(numRow(ch("*", 0.8f), divider(false), ch("7"), ch("8"), ch("9"), bk))
        val ok = key("\u2713", 0.8f, false, 28f) { enterKey() }
        val g = GradientDrawable()
        g.setColor(th.accent); g.cornerRadius = dp(40).toFloat()
        ok.background = g
        ok.setTextColor(th.onAccent)
        val space = nk("_____", 1.2f) { commit(" ") }
        space.setTextColor(th.text)
        r.addView(numRow(
            nk("ABC", 0.8f) { mode = layoutFor(lang); build() },
            divider(false), space, ch("0"), ch(".", 0.6f), ch(",", 0.6f), ok
        ))
    }

    // ---------- panels ----------
    private fun panelView(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val head = rowOf(
            key("ABC", 1.3f, true, 15f) { panel = ""; build() },
            key("😊", 1f, panel == "emoji", 20f) { panel = "emoji"; build() },
            key("🖼", 1f, panel == "sticker", 20f) { panel = "sticker"; build() },
            key("📋", 1f, panel == "clip", 20f) { panel = "clip"; build() },
            backKey(1.3f)
        )
        head.layoutParams.height = dp(46)
        c.addView(head)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyH * 4))
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body)
        when (panel) {
            "emoji" -> emojiGrid(body, Words.emoji, 8, 26f, 44)
            "sticker" -> {
                emojiGrid(body, Words.stickers, 5, 36f, 64)
                for (chunk in Words.textStickers.chunked(2)) {
                    val row = LinearLayout(this)
                    row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
                    for (s in chunk) {
                        val t = TextView(this)
                        t.text = s; t.gravity = Gravity.CENTER; t.textSize = 15f; t.setTextColor(th.text)
                        t.background = keyBg(th.key)
                        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3)); t.layoutParams = lp
                        t.setOnClickListener { buzz(); commit(s) }
                        row.addView(t)
                    }
                    body.addView(row)
                }
            }
            else -> {
                val clips = getList("clips")
                if (clips.isEmpty()) {
                    val t = TextView(this)
                    t.text = "ক্লিপবোর্ড খালি — কিছু কপি করুন"
                    t.setTextColor(th.dim); t.gravity = Gravity.CENTER; t.setPadding(0, dp(30), 0, 0)
                    body.addView(t)
                }
                for (s in clips) {
                    val t = TextView(this)
                    t.text = s; t.maxLines = 2; t.ellipsize = TextUtils.TruncateAt.END
                    t.setTextColor(th.text); t.textSize = 15f; t.setPadding(dp(12), dp(10), dp(12), dp(10))
                    t.background = keyBg(th.key)
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3)); t.layoutParams = lp
                    t.setOnClickListener { buzz(); commit(s) }
                    body.addView(t)
                }
            }
        }
        c.addView(sv)
        return c
    }

    private fun emojiGrid(body: LinearLayout, items: List<String>, cols: Int, size: Float, hDp: Int) {
        for (chunk in items.chunked(cols)) {
            val row = LinearLayout(this)
            row.weightSum = cols.toFloat()
            row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(hDp))
            for (e in chunk) {
                val t = TextView(this)
                t.text = e; t.textSize = size; t.gravity = Gravity.CENTER
                t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                t.setOnClickListener { buzz(); commit(e) }
                row.addView(t)
            }
            body.addView(row)
        }
    }

    // ---------- input actions ----------
    private fun flush() {
        if (comp.isEmpty()) return
        val w = Phonetic.convert(comp.toString())
        currentInputConnection?.commitText(w, 1)
        addRecent(w)
        comp.setLength(0)
    }

    private fun commit(s: String) {
        flush()
        currentInputConnection?.commitText(s, 1)
        lastBase = null
        refreshKar(); updateSuggestions()
    }

    private fun phon(ch: String) {
        comp.append(ch)
        currentInputConnection?.setComposingText(Phonetic.convert(comp.toString()), 1)
        updateSuggestions()
    }

    private fun doBackspace() {
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) {
            comp.deleteCharAt(comp.length - 1)
            if (comp.isEmpty()) ic.commitText("", 1)
            else ic.setComposingText(Phonetic.convert(comp.toString()), 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun onSpace() {
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) flush() else autoFixAndRemember()
        ic.commitText(" ", 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun autoFixAndRemember() {
        val ic = currentInputConnection ?: return
        val w = curWord()
        if (w.length < 2) return
        var out = w
        if (mode == "en" && prefs.getBoolean("autocorrect", true) && w.length >= 3 &&
            w.all { it in 'a'..'z' || it in 'A'..'Z' } && !Words.enSet.contains(w.lowercase())
        ) {
            val fix = Words.fix(w.lowercase())
            if (fix != null) {
                out = if (w[0].isUpperCase()) fix.replaceFirstChar { it.uppercaseChar() } else fix
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(out, 1)
            }
        }
        addRecent(out)
    }

    private fun enterKey() {
        flush()
        if (!sendDefaultEditorAction(true)) currentInputConnection?.commitText("\n", 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun switchLang() {
        flush()
        lang = if (lang == "bn") "en" else "bn"
        prefs.edit().putString("lang", lang).apply()
        mode = layoutFor(lang); panel = ""; shift = false; caps = false
        build()
    }

    private fun toggleBnLayout() {
        flush()
        val cur = prefs.getString("bnlayout", "classic")
        prefs.edit().putString("bnlayout", if (cur == "phonetic") "classic" else "phonetic").apply()
        lang = "bn"; prefs.edit().putString("lang", "bn").apply()
        mode = layoutFor("bn"); tools = false
        build()
    }

    private fun imePicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }


    // ---------- suggestions ----------
    private fun isWordChar(c: Char): Boolean {
        if (Character.isLetterOrDigit(c) || c == '\u09CD') return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun curWord(): String {
        if (comp.isNotEmpty()) return Phonetic.convert(comp.toString())
        val b = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString() ?: return ""
        var i = b.length
        while (i > 0 && isWordChar(b[i - 1])) i--
        return b.substring(i)
    }

    private fun suggest(): List<String> {
        val w = curWord()
        val rec = getList("recent")
        if (w.isEmpty()) {
            val base = if (lang == "bn") listOf("আমি", "আপনি", "ধন্যবাদ") else listOf("I", "The", "Hello")
            return (rec.take(3) + base).distinct().take(3)
        }
        val pool = rec + (if (w[0].code >= 0x0980) Words.bn else Words.en)
        val lw = w.lowercase()
        val m = pool.filter { it.lowercase().startsWith(lw) && it.lowercase() != lw }
        return (listOf(w) + m).distinct().take(3)
    }

    private fun updateSuggestions() {
        if (sug.size < 3) return
        val l = if (prefs.getBoolean("sugg", true)) suggest() else emptyList()
        for (i in 0 until 3) sug[i].text = l.getOrElse(i) { "" }
    }

    private fun pickSuggestion(s: String) {
        if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) {
            comp.setLength(0)
        } else {
            val w = curWord()
            if (w.isNotEmpty()) ic.deleteSurroundingText(w.length, 0)
        }
        ic.commitText("$s ", 1)
        addRecent(s)
        lastBase = null; refreshKar(); updateSuggestions()
    }
}
