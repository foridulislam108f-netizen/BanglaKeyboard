package com.banglakeys.keyboard

import android.content.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.inputmethodservice.InputMethodService
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

class KeyboardService : InputMethodService() {

    private lateinit var prefs: SharedPreferences
    private var root: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())

    private var th = Themes.get("dark")
    private var keyH = 48
    private var fs = 1f
    private var gap = 2
    private var flat = false
    private var lang = "bn"          // bn | en
    private var mode = "bn"          // bn (classic) | bnp (phonetic) | en | sym
    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var tools = false
    private var panel = ""           // "" | emoji | sticker | clip
    private var lastBase: String? = null
    private val comp = StringBuilder()   // phonetic roman buffer

    private val letters = ArrayList<Pair<TextView, String>>()
    private var shiftView: TextView? = null
    private val karViews = ArrayList<TextView>()
    private val sug = ArrayList<TextView>()

    private val vowels = listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "এ", "ঐ", "ও", "ঔ")
    private val kars = listOf("", "\u09BE", "\u09BF", "\u09C0", "\u09C1", "\u09C2", "\u09C7", "\u09C8", "\u09CB", "\u09CC")
    private val bnRows = listOf(
        listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"),
        listOf("ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"),
        listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"),
        listOf("স", "হ", "\u09DC", "\u09DD", "\u09DF", "ৎ", "ং", "ঃ", "ঁ")
    )

    // ---------- state added for speed / privacy ----------
    private var noLearn = false          // password / incognito fields: no suggestions, no learning
    private var lastSig = 0
    private var sugPending = false
    private var recentCache: List<String>? = null
    private var clipCm: ClipboardManager? = null

    private val sugRun = Runnable { sugPending = false; doUpdateSuggestions() }
    private val clipL = ClipboardManager.OnPrimaryClipChangedListener {
        try {
            val t = clipCm?.primaryClip?.getItemAt(0)?.text?.toString()
            if (!t.isNullOrBlank() && prefs.getBoolean("clipon", true)) pushList("clips", t, 20)
        } catch (e: Exception) { }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- live voice typing (text appears while you speak) ----------
    private var recognizer: SpeechRecognizer? = null
    private var voiceOn = false
    private var micView: View? = null
    private var voiceErrors = 0      // consecutive hard errors
    private var voiceSilent = 0      // consecutive rounds where nothing was heard
    private var voiceNeedSpace = false
    private var voiceCap = false
    private var voiceReady = false
    private var warmConn: ServiceConnection? = null   // keeps the speech service process alive while the keyboard is open

    private val restartListen = Runnable { listenNow() }
    private val stopGuard = Runnable {
        try { recognizer?.cancel() } catch (e: Exception) { }
        currentInputConnection?.finishComposingText()
    }

    // spoken punctuation: say "কমা" / "দাঁড়ি" / "নতুন লাইন" (or "comma", "full stop", "new line")
    private fun cmds(list: List<Pair<String, String>>, ic: Boolean): List<Pair<Regex, String>> = list.map { (p, s) ->
        val core = "(?<![\\p{L}\\p{M}])" + Regex.escape(p) + "(?![\\p{L}\\p{M}])"
        val re = if (s == "\n") "\\s*" + core + "\\s*" else "\\s*" + core
        (if (ic) Regex(re, RegexOption.IGNORE_CASE) else Regex(re)) to s
    }

    private val cmdBn by lazy {
        cmds(listOf(
            "প্রশ্নবোধক চিহ্ন" to "?", "পূর্ণচ্ছেদ" to "।",
            "\u09A6\u09BE\u0981\u09DC\u09BF" to "।", "\u09A6\u09BE\u0981\u09A1\u09BC\u09BF" to "।",
            "\u09A6\u09BE\u09DC\u09BF" to "।", "\u09A6\u09BE\u09A1\u09BC\u09BF" to "।",
            "কমা" to ",", "নতুন লাইন" to "\n"
        ), false)
    }
    private val cmdEn by lazy {
        cmds(listOf("question mark" to "?", "full stop" to ".", "period" to ".", "comma" to ",", "new line" to "\n"), true)
    }

    private fun voiceText(raw: String): String {
        var s = raw
        for ((re, sym) in (if (lang == "bn") cmdBn else cmdEn)) s = s.replace(re, sym)
        s = s.trim { it == ' ' }
        if (s.isEmpty()) return s
        if (voiceCap) s = s.replaceFirstChar { it.uppercaseChar() }
        if (voiceNeedSpace && s[0] != '\n' && s[0] !in ",.?!।") s = " " + s
        return s
    }

    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {
            // the recognizer is really listening now: mic turns green + tiny tick = "you can speak"
            if (!voiceOn) return
            if (!voiceReady) { voiceReady = true; setMic(0xFF1B8A3E.toInt()); buzz() }
        }
        override fun onBeginningOfSpeech() { voiceSilent = 0 }
        override fun onRmsChanged(v: Float) {
            val m = micView ?: return
            if (!voiceOn) return
            val s = 1f + v.coerceIn(0f, 10f) * 0.025f     // mic button "breathes" with your voice
            m.scaleX = s; m.scaleY = s
        }
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onPartialResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (t.isEmpty()) return
            val s = voiceText(t)
            if (s.isNotEmpty()) currentInputConnection?.setComposingText(s, 1)
        }

        override fun onResults(r: Bundle?) {
            h.removeCallbacks(stopGuard)
            deliver(r)
            if (voiceOn) h.post(restartListen)   // keep listening with no gap (fewer lost words)
        }

        // Android 13+: one continuous session, every finished sentence arrives here (no restart gap at all)
        override fun onSegmentResults(r: Bundle) { deliver(r) }

        override fun onEndOfSegmentedSession() {
            h.removeCallbacks(stopGuard)
            currentInputConnection?.finishComposingText()
            lastBase = null
            if (voiceOn) h.post(restartListen)
        }

        override fun onError(e: Int) {
            h.removeCallbacks(stopGuard)
            currentInputConnection?.finishComposingText()
            if (!voiceOn) return
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    voiceSilent++
                    if (voiceSilent >= 4) { stopVoice(); toast("কথা শোনা যায়নি — আবার মাইক চাপুন") }
                    else h.postDelayed(restartListen, 100)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    try { recognizer?.cancel() } catch (x: Exception) { }
                    h.postDelayed(restartListen, 400)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stopVoice(); askMicPermission() }
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> { stopVoice(); toast("ইন্টারনেট চেক করুন") }
                SpeechRecognizer.ERROR_AUDIO -> { stopVoice(); toast("মাইক ব্যবহার করা যাচ্ছে না (অন্য অ্যাপ ব্যবহার করছে?)") }
                12, 13 -> { stopVoice(); toast("এই ভাষার ভয়েস টাইপ এই ফোনে নেই") }
                else -> {
                    // e.g. ERROR_CLIENT: rebuild the recognizer a couple of times before giving up
                    voiceErrors++
                    if (voiceErrors <= 2) {
                        try { recognizer?.destroy() } catch (x: Exception) { }
                        recognizer = null
                        h.postDelayed(restartListen, 300)
                    } else { stopVoice(); toast("ভয়েস টাইপ চালু করা যায়নি ($e)") }
                }
            }
        }
    }

    /** commit the final text of a finished sentence / segment */
    private fun deliver(r: Bundle?) {
        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        val ic = currentInputConnection
        val s = if (t.isNullOrEmpty()) "" else voiceText(t)
        if (s.isNotEmpty() && ic != null) {
            ic.commitText(if (s.endsWith("\n")) s else s + " ", 1)
            voiceErrors = 0; voiceSilent = 0
        } else {
            ic?.finishComposingText()
        }
        lastBase = null
        prepRound()
    }

    /** decide spacing / capital letter for the next piece of text (before any partial text is shown) */
    private fun prepRound() {
        val b = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        voiceNeedSpace = b.isNotEmpty() && !b.last().isWhitespace() && b.last() !in "([{"
        voiceCap = lang == "en" && (b.isBlank() || b.trimEnd().last() in ".!?")
    }

    /** idle mic circle: the key colour made softer (less white glow) */
    private fun micIdle(): Int {
        val c = th.keyAlt
        return (c and 0x00FFFFFF) or ((((c ushr 24) * 0.5f).toInt()) shl 24)
    }

    private fun setMic(color: Int) {
        micView?.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(color) }
    }

    /** Create the recognizer early and wake up the speech service so the first mic tap does not wait for it. */
    private fun warmVoice() {
        if (voiceOn || warmConn != null || noLearn) return
        try {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(recListener)
            }
            var cn: ComponentName? = null
            try {
                cn = android.provider.Settings.Secure.getString(contentResolver, "voice_recognition_service")
                    ?.let { ComponentName.unflattenFromString(it) }
            } catch (e: Exception) { }
            if (cn == null) {
                cn = packageManager.queryIntentServices(Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0)
                    .firstOrNull()?.serviceInfo?.let { ComponentName(it.packageName, it.name) }
            }
            if (cn == null) return
            val conn = object : ServiceConnection {
                override fun onServiceConnected(n: ComponentName?, b: IBinder?) {}
                override fun onServiceDisconnected(n: ComponentName?) {}
            }
            val ok = bindService(Intent(android.speech.RecognitionService.SERVICE_INTERFACE).setComponent(cn), conn, Context.BIND_AUTO_CREATE)
            if (ok) warmConn = conn else try { unbindService(conn) } catch (e: Exception) { }
        } catch (e: Exception) { }
    }

    private fun coolVoice() {
        val c = warmConn ?: return
        warmConn = null
        try { unbindService(c) } catch (e: Exception) { }
    }

    private fun askMicPermission() {
        startActivity(Intent(this, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun listenNow() {
        if (!voiceOn) return
        try {
            prepRound()

            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(recListener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "bn") "bn-BD" else "en-US")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            if (Build.VERSION.SDK_INT >= 33) i.putExtra("android.speech.extra.SEGMENTED_SESSION", true)
            recognizer?.startListening(i)
        } catch (e: Exception) {
            stopVoice()
            toast("ভয়েস টাইপ পাওয়া যাচ্ছে না")
        }
    }

    private fun startVoice() {
        if (voiceOn) { stopVoice(true); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            askMicPermission(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে ভয়েস রিকগনিশন সার্ভিস নেই (Google অ্যাপ / Speech Services লাগবে)")
            return
        }
        h.removeCallbacks(stopGuard)
        flush()
        voiceOn = true; voiceErrors = 0; voiceSilent = 0; voiceReady = false
        setMic(0xFFE0A100.toInt())      // amber = starting; turns green when it is really listening
        listenNow()
    }

    /** finish = true: user tapped the mic, let the recognizer deliver its last words first. */
    private fun stopVoice(finish: Boolean = false) {
        val was = voiceOn
        voiceOn = false; voiceErrors = 0; voiceSilent = 0; voiceReady = false
        h.removeCallbacks(restartListen)
        micView?.let {
            it.scaleX = 1f; it.scaleY = 1f
            it.background = GradientDrawable().also { g -> g.shape = GradientDrawable.OVAL; g.setColor(micIdle()) }
        }
        if (finish && was) {
            try { recognizer?.stopListening() } catch (e: Exception) { }
            h.removeCallbacks(stopGuard); h.postDelayed(stopGuard, 1800)
        } else {
            h.removeCallbacks(stopGuard)
            try { recognizer?.stopListening(); recognizer?.cancel() } catch (e: Exception) { }
            currentInputConnection?.finishComposingText()
        }
    }

    /** any normal typing key stops dictation first (so typed keys never overwrite live voice text) */
    private fun voiceOff() { if (voiceOn) stopVoice() }

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        Words.load(this)
        clipCm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipCm?.addPrimaryClipChangedListener(clipL)
    }

    override fun onDestroy() {
        voiceOn = false
        h.removeCallbacksAndMessages(null); sugPending = false
        try { clipCm?.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { }
        try { recognizer?.destroy() } catch (e: Exception) { }
        coolVoice()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        root = r
        applyPrefs()
        mode = layoutFor(lang)
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        comp.setLength(0); lastBase = null; tools = false; panel = ""
        recentCache = null
        applyPrefs()
        val inp = info?.inputType ?: 0
        val cls = inp and InputType.TYPE_MASK_CLASS
        val va = inp and InputType.TYPE_MASK_VARIATION
        noLearn = (cls == InputType.TYPE_CLASS_TEXT && (va == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                va == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || va == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                (inp and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && va == InputType.TYPE_NUMBER_VARIATION_PASSWORD) ||
                ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        warmVoice()
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) "num" else layoutFor(lang)
        caps = false
        shift = mode == "en" && (currentInputConnection?.getTextBeforeCursor(1, 0)?.isEmpty() ?: false)
        // only rebuild all the key views when something really changed (keyboard opens much faster)
        if ((root?.childCount ?: 0) == 0 || sig() != lastSig) build()
        else { refreshShift(); refreshKar(); updateSuggestions() }
    }

    private fun sig(): Int = java.util.Objects.hash(
        prefs.all.filterKeys { k -> k != "clips" && k != "recent" }.hashCode(), mode, tools, panel, voiceOn
    )

    override fun onFinishInputView(finishingInput: Boolean) {
        if (voiceOn) stopVoice()
        try { recognizer?.cancel() } catch (e: Exception) { }
        coolVoice()
        h.removeCallbacksAndMessages(null); sugPending = false   // also stops a stuck backspace-repeat
        super.onFinishInputView(finishingInput)
    }

    override fun onFinishInput() {
        comp.setLength(0)
        super.onFinishInput()
    }

    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) {
        super.onUpdateSelection(a, b, c, d, e, f)
        if (comp.isNotEmpty() && (e == -1 || f == -1)) comp.setLength(0)
        updateSuggestions()
    }

    private fun applyPrefs() {
        th = Themes.get(prefs.getString("theme", "dark") ?: "dark", prefs)
        keyH = prefs.getInt("keyh", 48)
        fs = prefs.getInt("fscale", 100) / 100f
        gap = prefs.getInt("gap", 2)
        flat = prefs.getBoolean("flat", false)
        lang = prefs.getString("lang", "bn") ?: "bn"
    }

    private fun layoutFor(l: String): String =
        if (l == "en") "en" else if (prefs.getString("bnlayout", "classic") == "phonetic") "bnp" else "bn"

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buzz() {
        if (prefs.getBoolean("vibrate", true)) root?.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun keyBg(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(th.radius).toFloat()
        if (th.stroke != 0) g.setStroke(dp(1), th.stroke)
        return g
    }

    private fun getList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("\u0001").filter { it.isNotEmpty() }

    private fun pushList(k: String, v: String, max: Int) {
        val l = getList(k).toMutableList()
        l.remove(v); l.add(0, v)
        if (k == "recent") recentCache = null
        prefs.edit().putString(k, l.take(max).joinToString("\u0001")).apply()
    }

    private fun addRecent(w: String) { if (!noLearn && w.length >= 2) pushList("recent", w, 40) }

    private fun recent(): List<String> = recentCache ?: getList("recent").also { recentCache = it }

    private fun key(
        label: String, w: Float = 1f, alt: Boolean = false, size: Float = 20f,
        long: (() -> Unit)? = null, hint: String? = null, tap: () -> Unit
    ): TextView {
        val t = IconKey(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(th.text)
        t.textSize = size * th.scale * fs
        t.background = if (flat && !alt) null else keyBg(if (alt) th.keyAlt else th.key)
        if (hint != null && prefs.getBoolean("hints", true)) {
            t.hintText = hint; t.hintColor = th.dim; t.hintSize = dp(11).toFloat()
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        lp.setMargins(dp(gap), dp(3), dp(gap), dp(3))
        t.layoutParams = lp
        t.setOnClickListener { buzz(); tap() }   // only reached by accessibility (TalkBack); touches are handled below
        val lg: (() -> Unit)? = long ?: (if (hint != null) ({ commit(hint) }) else null)
        var done = false
        val tapRun = Runnable { tap() }   // posted (not called inline) so build() never runs in the middle of a touch dispatch
        val lpRun = Runnable { done = true; buzz(); lg?.invoke() }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.55f; done = false
                    if (lg == null) { done = true; buzz(); h.post(tapRun) }      // no long-press on this key: type instantly on touch-down
                    else h.postDelayed(lpRun, 300)
                }
                MotionEvent.ACTION_MOVE -> if (lg != null && !done) {
                    val s = dp(14)
                    if (e.x < -s || e.y < -s || e.x > v.width + s || e.y > v.height + s) { done = true; h.removeCallbacks(lpRun) }
                }
                MotionEvent.ACTION_UP -> {
                    v.alpha = 1f
                    if (lg != null) { h.removeCallbacks(lpRun); if (!done) { done = true; buzz(); h.post(tapRun) } }
                }
                MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; h.removeCallbacks(lpRun); done = true }
            }
            true
        }
        return t
    }

    private fun ik(kind: String, w: Float = 1f, alt: Boolean = false, long: (() -> Unit)? = null, tap: () -> Unit): IconKey {
        val t = key("", w, alt, 20f, long, null, tap) as IconKey
        t.kind = kind
        return t
    }

    private fun rowOf(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyH))
        for (x in v) l.addView(x)
        return l
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        return v
    }

    private fun backKey(w: Float): TextView {
        val t = ik("back", w, true) { }
        val rep = object : Runnable {
            override fun run() { doBackspace(); h.postDelayed(this, 45) }
        }
        t.setOnClickListener(null)
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.alpha = 0.55f; buzz(); doBackspace(); h.postDelayed(rep, 350) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; h.removeCallbacks(rep) }
            }
            true
        }
        return t
    }

    // ---------- build UI ----------
    private fun build() {
        val r = root ?: return
        r.removeAllViews(); letters.clear(); karViews.clear(); sug.clear(); shiftView = null
        r.orientation = LinearLayout.VERTICAL
        val g = th.grad
        r.background = if (g != null) GradientDrawable(GradientDrawable.Orientation.TL_BR, g)
        else GradientDrawable().also { it.setColor(th.bg) }
        r.setPadding(dp(3), dp(2), dp(3), dp(2))
        if (mode != "num") r.addView(topBar())
        if (panel.isNotEmpty()) {
            r.addView(panelView())
        } else {
            when (mode) {
                "bn" -> bnLayout(r)
                "sym" -> symLayout(r)
                "num" -> numLayout(r)
                else -> qwerty(r)
            }
            if (mode != "num") r.addView(bottomRow())
        }
        refreshKar(); refreshShift(); updateSuggestions()
        lastSig = sig()
    }

    private fun tbtn(label: String, w: Float = 0f, f: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label; t.textSize = 20f; t.gravity = Gravity.CENTER; t.setTextColor(th.text)
        t.layoutParams = if (w > 0f) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        else LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT)
        t.setOnClickListener { buzz(); f() }
        return t
    }

    private fun ibtn(kind: String, w: Float = 0f, f: () -> Unit): IconView {
        val v = IconView(this, kind, th.text)
        v.layoutParams = if (w > 0f) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        else LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT)
        v.setOnClickListener { buzz(); f() }
        v.setOnTouchListener { x, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> x.alpha = 0.5f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.alpha = 1f
            }
            false
        }
        return v
    }

    private fun topBar(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        if (tools) {
            l.addView(ibtn("grid", 1f) { tools = false; build() }.also { it.color = th.accent })
            l.addView(ibtn("clip", 1f) { panel = "clip"; tools = false; build() })
            l.addView(ibtn("emoji", 1f) { panel = "emoji"; tools = false; build() })
            l.addView(ibtn("sticker", 1f) { panel = "sticker"; tools = false; build() })
            l.addView(ibtn("num", 1f) { flush(); mode = "num"; tools = false; build() })
            l.addView(ibtn("lang", 1f) { toggleBnLayout() })
            l.addView(ibtn("gear", 1f) { openSettings() })
        } else {
            l.addView(ibtn("grid") { tools = true; build() })
            for (i in 0 until 3) {
                val t = TextView(this)
                t.gravity = Gravity.CENTER; t.textSize = 17f; t.setTextColor(th.text)
                t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END
                t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                t.setOnClickListener { pickSuggestion(t.text.toString()) }
                sug.add(t); l.addView(t)
            }
        }
        val mic = ibtn("mic") { startVoice() }
        micView = mic
        mic.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(if (voiceOn) (if (voiceReady) 0xFF1B8A3E.toInt() else 0xFFE0A100.toInt()) else micIdle()) }
        val mlp = LinearLayout.LayoutParams(dp(40), dp(40))
        mlp.setMargins(dp(4), 0, dp(4), 0)
        mic.layoutParams = mlp
        l.addView(mic)
        return l
    }

    private fun bnLayout(r: LinearLayout) {
        val kr = ArrayList<View>()
        for (i in 0 until 10) {
            val t = key("", 1f, false, 20f) { karTap(i) }
            t.setTextColor(th.text)
            karViews.add(t); kr.add(t)
        }
        r.addView(rowOf(*kr.toTypedArray()))
        for (i in 0 until 3) r.addView(rowOf(*bnRows[i].map { bnKey(it) }.toTypedArray()))
        val last = ArrayList<View>()
        for (c in bnRows[3]) last.add(bnKey(c, if (c == "ং" || c == "ঃ" || c == "ঁ") 0.8667f else 1f))
        last.add(backKey(1.4f))
        r.addView(rowOf(*last.toTypedArray()))
    }

    private fun bnKey(c: String, w: Float = 1f): TextView {
        val isBase = c != "ং" && c != "ঃ" && c != "ঁ"
        return key(c, w, size = 22f) {
            commit(c)
            if (isBase) { lastBase = c; refreshKar() }
        }
    }

    private fun karLabel(i: Int): String { val b = lastBase; return if (b == null) vowels[i] else b + kars[i] }

    private fun refreshKar() {
        for (i in karViews.indices) {
            val s = karLabel(i)
            if (karViews[i].text.toString() != s) karViews[i].text = s
        }
    }

    private fun karTap(i: Int) {
        voiceOff()
        val ic = currentInputConnection ?: return
        val lab = karLabel(i)
        val b = lastBase
        if (b != null) ic.deleteSurroundingText(b.length, 0)
        ic.commitText(lab, 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun qwerty(r: LinearLayout) {
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val digits = "1234567890"
        r.addView(rowOf(*rows[0].mapIndexed { i, c -> letterKey(c, digits[i].toString()) }.toTypedArray()))
        val r2 = ArrayList<View>()
        r2.add(spacer(0.5f))
        for ((i, c) in rows[1].withIndex()) r2.add(letterKey(c, "@#\$%&-+()"[i].toString()))
        r2.add(spacer(0.5f))
        r.addView(rowOf(*r2.toTypedArray()))
        val r3 = ArrayList<View>()
        val sh = ik("shift", 1.5f, true) {
            val now = SystemClock.uptimeMillis()
            if (now - lastShiftTap < 350) { caps = true; shift = true }
            else if (caps) { caps = false; shift = false }
            else shift = !shift
            lastShiftTap = now
            refreshShift()
        }
        shiftView = sh
        r3.add(sh)
        for ((i, c) in rows[2].withIndex()) r3.add(letterKey(c, "*\"':;!?"[i].toString()))
        r3.add(backKey(1.5f))
        r.addView(rowOf(*r3.toTypedArray()))
    }

    private fun letterKey(c: Char, digit: String?): TextView {
        val lg: (() -> Unit)? = if (digit != null) ({ commit(digit) }) else null
        val t = key(c.toString(), 1f, false, 20f, null, digit) { typeLetter(c) }
        letters.add(Pair(t, c.toString()))
        return t
    }

    private fun typeLetter(c: Char) {
        val ch = if (shift) c.uppercaseChar() else c
        if (mode == "bnp") phon(ch.toString()) else commit(ch.toString())
        if (shift && !caps) { shift = false; refreshShift() }
    }

    private fun refreshShift() {
        for (p in letters) p.first.text = if (shift) p.second.uppercase() else p.second
        val s = shiftView ?: return
        val on = shift || caps
        s.background = keyBg(if (on) th.accent else th.keyAlt)
        s.setTextColor(if (on) th.onAccent else th.text)
        (s as? IconKey)?.kind = if (caps) "caps" else if (shift) "shiftOn" else "shift"
        s.invalidate()
    }

    private fun symLayout(r: LinearLayout) {
        val d = if (lang == "bn") "১২৩৪৫৬৭৮৯০" else "1234567890"
        r.addView(strRow(d))
        r.addView(strRow("@#\$%&-+()/"))
        val l = ArrayList<View>()
        for (ch in "=*\"':;!?।") l.add(key(ch.toString()) { commit(ch.toString()) })
        l.add(backKey(1f))
        r.addView(rowOf(*l.toTypedArray()))
    }

    private fun strRow(s: String): LinearLayout =
        rowOf(*s.map { ch -> key(ch.toString()) { commit(ch.toString()) } }.toTypedArray())

    private fun bottomRow(): LinearLayout {
        val sym = mode == "sym"
        val v = ArrayList<View>()
        v.add(key(if (sym) "ABC" else if (lang == "bn") "?১২৩" else "?123", 1.5f, true, 15f,
            if (sym) null else ({ flush(); mode = "sym"; build() })) {
            flush(); mode = if (sym) layoutFor(lang) else "num"; build()
        })
        v.add(ik("emoji", 1f, true, { panel = "emoji"; build() }) { commit(",") }.also {
            it.iconDy = dp(3).toFloat(); it.hintBaseline = dp(15).toFloat()   // smiley a bit lower, comma up in the corner (clear of the face)
            it.hintText = ","; it.hintColor = th.text; it.hintSize = dp(19).toFloat(); it.hintBold = true
        })
        v.add(ik("globe", 1f, false, { imePicker() }) { switchLang() })
        val label = when (mode) { "bn" -> "বাংলা"; "bnp" -> "বাংলা (ফোনেটিক)"; "en" -> "English"; else -> "" }
        v.add(key(label, if (mode == "bn") 3.2f else 4f, false, 14f, { imePicker() }) { onSpace() })
        if (mode == "bn") {
            v.add(key("\u25CC\u09CD", 1f, true, 18f, { commit("\u09CD\u09AF") }) { commit("\u09CD") })
        }
        val dot = if (lang == "bn") "।" else "."
        v.add(key(dot, 1f, true, 20f) { commit(dot) })
        val enter = ik("enter", 1.5f, false) { enterKey() }
        val ea = prefs.getBoolean("enteraccent", true)
        enter.background = keyBg(if (ea) th.accent else th.keyAlt)
        enter.setTextColor(if (ea) th.onAccent else th.text)
        v.add(enter)
        return rowOf(*v.toTypedArray())
    }

    // ---------- number pad ----------
    // 5 columns:  [ + * / ] [1 4 7] [2 5 8 0] [3 6 9] [ % space back ok ]
    private val bnDigits = "০১২৩৪৫৬৭৮৯"

    private fun numRow(vararg v: View): LinearLayout {
        val l = rowOf(*v)
        l.layoutParams.height = dp(keyH + 10)
        return l
    }

    /** plain symbol key (no tile), like the left / right columns of the number pad */
    private fun nsym(label: String, w: Float, hint: String? = null): TextView {
        val t = key(label, w, false, 24f, null, hint) { commit(label) }
        t.background = null
        t.isSingleLine = true
        return t
    }

    /** digit tile; in Bangla mode a small Bangla digit is shown and typed on long-press */
    private fun ndig(d: String, w: Float = 1f): TextView {
        val bn = if (lang == "bn") bnDigits[d[0] - '0'].toString() else null
        val t = key(d, w, false, 26f, null, bn) { commit(d) }
        t.isSingleLine = true
        return t
    }

    private fun roundOk(ok: View) {
        // perfect circle in the accent colour, whatever the cell size is
        ok.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            val w = r - l; val hh = b - t
            val d = minOf(w, hh)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(th.accent)
            v.background = InsetDrawable(g, maxOf(0, (w - d) / 2), maxOf(0, (hh - d) / 2), maxOf(0, (w - d) / 2), maxOf(0, (hh - d) / 2))
        }
    }

    /** put a key into a vertical column: full width, equal share of the height */
    private fun <T : View> vcell(v: T): T {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        lp.setMargins(dp(gap), dp(1), dp(gap), dp(1))
        v.layoutParams = lp
        return v
    }

    private fun vcol(w: Float, vararg v: View): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        for (x in v) c.addView(x)
        return c
    }

    // left column: 4 symbols (+ - * /) share the height of the 3 digit rows
    private fun numLayout(r: LinearLayout) {
        val cs = 0.85f   // side columns are a little narrower than the digit columns
        val ok = ik("check", cs, false) { enterKey() }
        ok.setTextColor(th.onAccent)
        roundOk(ok)
        val bk = backKey(cs)
        bk.background = null
        val sp = ik("space", cs, false) { onSpace() }
        sp.background = null

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 3f)
        mid.addView(numRow(ndig("1"), ndig("2"), ndig("3")))
        mid.addView(numRow(ndig("4"), ndig("5"), ndig("6")))
        mid.addView(numRow(ndig("7"), ndig("8"), ndig("9")))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp((keyH + 10) * 3))
        top.addView(vcol(cs, vcell(nsym("+", cs, "@")), vcell(nsym("-", cs, "#")), vcell(nsym("*", cs)), vcell(nsym("/", cs))))
        top.addView(mid)
        top.addView(vcol(cs, vcell(nsym("%", cs, "$")), vcell(sp), vcell(bk)))
        r.addView(top)

        val abc = key("ABC", cs, true, 15f, { flush(); mode = "sym"; build() }) { flush(); mode = layoutFor(lang); build() }
        abc.background = GradientDrawable().also { it.setColor(th.keyAlt); it.cornerRadius = dp(40).toFloat() }
        r.addView(numRow(
            abc,
            nsym(",", 0.5f), nsym("?", 0.5f),
            ndig("0"),
            nsym("=", 0.5f), nsym(".", 0.5f),
            ok
        ))
    }

    // ---------- panels ----------
    private fun panelView(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val head = rowOf(
            key("ABC", 1.3f, true, 15f) { panel = ""; build() },
            ik("emoji", 1f, panel == "emoji") { panel = "emoji"; build() },
            ik("sticker", 1f, panel == "sticker") { panel = "sticker"; build() },
            ik("clip", 1f, panel == "clip") { panel = "clip"; build() },
            backKey(1.3f)
        )
        head.layoutParams.height = dp(46)
        c.addView(head)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyH * 4))
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body)
        when (panel) {
            "emoji" -> emojiGrid(body, Words.emoji, 8, 26f, 44)
            "sticker" -> {
                emojiGrid(body, Words.stickers, 5, 36f, 64)
                for (chunk in Words.textStickers.chunked(2)) {
                    val row = LinearLayout(this)
                    row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
                    for (s in chunk) {
                        val t = TextView(this)
                        t.text = s; t.gravity = Gravity.CENTER; t.textSize = 15f; t.setTextColor(th.text)
                        t.background = keyBg(th.key)
                        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3)); t.layoutParams = lp
                        t.setOnClickListener { buzz(); commit(s) }
                        row.addView(t)
                    }
                    body.addView(row)
                }
            }
            else -> {
                val clips = getList("clips")
                if (clips.isEmpty()) {
                    val t = TextView(this)
                    t.text = "ক্লিপবোর্ড খালি — কিছু কপি করুন"
                    t.setTextColor(th.dim); t.gravity = Gravity.CENTER; t.setPadding(0, dp(30), 0, 0)
                    body.addView(t)
                }
                for (s in clips) {
                    val t = TextView(this)
                    t.text = s; t.maxLines = 2; t.ellipsize = TextUtils.TruncateAt.END
                    t.setTextColor(th.text); t.textSize = 15f; t.setPadding(dp(12), dp(10), dp(12), dp(10))
                    t.background = keyBg(th.key)
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3)); t.layoutParams = lp
                    t.setOnClickListener { buzz(); commit(s) }
                    body.addView(t)
                }
            }
        }
        c.addView(sv)
        return c
    }

    private fun emojiGrid(body: LinearLayout, items: List<String>, cols: Int, size: Float, hDp: Int) {
        for (chunk in items.chunked(cols)) {
            val row = LinearLayout(this)
            row.weightSum = cols.toFloat()
            row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(hDp))
            for (e in chunk) {
                val t = TextView(this)
                t.text = e; t.textSize = size; t.gravity = Gravity.CENTER
                t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                t.setOnClickListener { buzz(); commit(e) }
                row.addView(t)
            }
            body.addView(row)
        }
    }

    // ---------- input actions ----------
    private fun flush() {
        if (comp.isEmpty()) return
        val w = Phonetic.convert(comp.toString())
        currentInputConnection?.commitText(w, 1)
        addRecent(w)
        comp.setLength(0)
    }

    private fun commit(s: String) {
        voiceOff()
        flush()
        currentInputConnection?.commitText(s, 1)
        lastBase = null
        refreshKar(); updateSuggestions()
    }

    private fun phon(ch: String) {
        voiceOff()
        comp.append(ch)
        currentInputConnection?.setComposingText(Phonetic.convert(comp.toString()), 1)
        updateSuggestions()
    }

    private fun doBackspace() {
        voiceOff()
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) {
            comp.deleteCharAt(comp.length - 1)
            if (comp.isEmpty()) ic.commitText("", 1)
            else ic.setComposingText(Phonetic.convert(comp.toString()), 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun onSpace() {
        voiceOff()
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) flush() else autoFixAndRemember()
        ic.commitText(" ", 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun autoFixAndRemember() {
        val ic = currentInputConnection ?: return
        val w = curWord()
        if (w.length < 2) return
        var out = w
        if (mode == "en" && !noLearn && prefs.getBoolean("autocorrect", true) && w.length >= 3 &&
            w.all { it in 'a'..'z' || it in 'A'..'Z' } && !Words.enSet.contains(w.lowercase())
        ) {
            val fix = Words.fix(w.lowercase())?.takeIf { !w.lowercase().startsWith(it) }
            if (fix != null) {
                out = if (w[0].isUpperCase()) fix.replaceFirstChar { it.uppercaseChar() } else fix
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(out, 1)
            }
        }
        addRecent(out)
    }

    private fun enterKey() {
        voiceOff()
        flush()
        if (!sendDefaultEditorAction(true)) currentInputConnection?.commitText("\n", 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun switchLang() {
        flush()
        lang = if (lang == "bn") "en" else "bn"
        prefs.edit().putString("lang", lang).apply()
        mode = layoutFor(lang); panel = ""; shift = false; caps = false
        build()
    }

    private fun toggleBnLayout() {
        flush()
        val cur = prefs.getString("bnlayout", "classic")
        prefs.edit().putString("bnlayout", if (cur == "phonetic") "classic" else "phonetic").apply()
        lang = "bn"; prefs.edit().putString("lang", "bn").apply()
        mode = layoutFor("bn"); tools = false
        build()
    }

    private fun imePicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }


    // ---------- suggestions ----------
    private fun isWordChar(c: Char): Boolean {
        if (Character.isLetterOrDigit(c) || c == '\u09CD') return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun curWord(): String {
        if (comp.isNotEmpty()) return Phonetic.convert(comp.toString())
        val b = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString() ?: return ""
        var i = b.length
        while (i > 0 && isWordChar(b[i - 1])) i--
        return b.substring(i)
    }

    private fun suggest(): List<String> {
        val w = curWord()
        val rec = recent()
        if (w.isEmpty()) {
            val base = if (lang == "bn") listOf("আমি", "আপনি", "ধন্যবাদ") else listOf("I", "The", "Hello")
            return (rec.take(3) + base).distinct().take(3)
        }
        val out = ArrayList<String>(3)
        out.add(w)
        fun scan(src: List<String>) {
            for (x in src) {
                if (out.size >= 3) return
                if (x.startsWith(w, ignoreCase = true) && !x.equals(w, ignoreCase = true) && !out.contains(x)) out.add(x)
            }
        }
        val isBn = w[0].code >= 0x0980
        scan(rec)
        scan(if (isBn) Words.bn else Words.en)
        // phonetic loose match: "ami" -> আমি also offers আমার, আমরা (compare words with vowel signs removed)
        if (isBn && comp.isNotEmpty() && out.size < 3) {
            val k = skel(w)
            if (skelSrc !== Words.bn) { skelSrc = Words.bn; skelList = Words.bn.map { skel(it) } }
            val loose = ArrayList<String>()
            for (x in rec) if (skel(x).startsWith(k)) loose.add(x)
            for (i in Words.bn.indices) if (skelList[i].startsWith(k)) loose.add(Words.bn[i])
            for (x in loose.distinct().sortedBy { it.length }) {   // shorter (more common) words first
                if (out.size >= 3) break
                if (!out.contains(x)) out.add(x)
            }
        }
        return out
    }

    private val karRe = Regex("[\u09BE-\u09CC]")
    private var skelSrc: List<String>? = null
    private var skelList: List<String> = emptyList()
    private fun skel(x: String) = x.replace(karRe, "")

    /** Coalesced: many calls during one key press -> one cheap update right after the key has been handled. */
    private fun updateSuggestions() {
        if (sug.size < 3 || sugPending) return
        sugPending = true
        h.post(sugRun)
    }

    private fun doUpdateSuggestions() {
        if (sug.size < 3) return
        val l = if (!noLearn && prefs.getBoolean("sugg", true)) suggest() else emptyList()
        for (i in 0 until 3) {
            val s = l.getOrElse(i) { "" }
            if (sug[i].text.toString() != s) sug[i].text = s
        }
    }

    private fun pickSuggestion(s: String) {
        if (s.isEmpty()) return
        voiceOff()
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) {
            comp.setLength(0)
        } else {
            val w = curWord()
            if (w.isNotEmpty()) ic.deleteSurroundingText(w.length, 0)
        }
        ic.commitText("$s ", 1)
        addRecent(s)
        lastBase = null; refreshKar(); updateSuggestions()
    }
}
