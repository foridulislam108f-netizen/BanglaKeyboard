package com.banglakeys.keyboard

import android.content.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.inputmethodservice.InputMethodService
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

class KeyboardService : InputMethodService() {

    private lateinit var prefs: SharedPreferences
    private var root: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())

    private var th = Themes.get("dark")
    private var keyH = 48
    private var padB = 0          // extra bottom padding (px)
    private var fs = 1f
    private var gap = 2
    private var flat = false
    private var lang = "bn"          // bn | en
    private var mode = "bn"          // bn (classic) | bnp (phonetic) | en | sym
    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var tools = false
    private var panel = ""           // "" | emoji | sticker | clip
    private var lastBase: String? = null
    private val comp = StringBuilder()   // phonetic roman buffer

    private val letters = ArrayList<Pair<TextView, String>>()
    private var shiftView: TextView? = null
    private val karViews = ArrayList<TextView>()
    private val sug = ArrayList<TextView>()
    private val SUG_N = 8                 // একসাথে কয়টি সাজেশন দেখাবে
    private var sugScroll: HorizontalScrollView? = null
    private var voiceBox: View? = null       // ভয়েস চালু থাকলে সাজেশন বারের জায়গায় "বলুন" + সাউন্ড-ওয়েভ
    private var waveView: WaveView? = null
    private val VOICE_GREEN = 0xFF1B8A3E.toInt()

    /** ভয়েস কী চাপলে সাজেশন বারে "বলুন" দেখায়; বন্ধ হলে আবার সাজেশন ফিরে আসে */
    private fun showVoiceBar(on: Boolean) {
        val vb = voiceBox ?: return
        vb.visibility = if (on) View.VISIBLE else View.GONE
        sugScroll?.visibility = if (on) View.GONE else View.VISIBLE
        waveView?.let { it.color = if (on && voiceReady) VOICE_GREEN else 0xFF9E9E9E.toInt(); it.reset() }
    }

    private val vowels = listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "এ", "ঐ", "ও", "ঔ")
    private val kars = listOf("", "\u09BE", "\u09BF", "\u09C0", "\u09C1", "\u09C2", "\u09C7", "\u09C8", "\u09CB", "\u09CC")
    private val bnRows = listOf(
        listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"),
        listOf("ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"),
        listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"),
        listOf("স", "হ", "\u09DC", "\u09DD", "\u09DF", "ৎ", "ং", "ঃ", "ঁ")
    )

    // ---------- state added for speed / privacy ----------
    private var noLearn = false          // password / incognito fields: no suggestions, no learning
    private var lastSig = 0
    private var sugPending = false
    private var recentCache: List<String>? = null
    private var clipCm: ClipboardManager? = null

    private val sugRun = Runnable { sugPending = false; doUpdateSuggestions() }
    private val clipL = ClipboardManager.OnPrimaryClipChangedListener {
        try {
            val t = clipCm?.primaryClip?.getItemAt(0)?.text?.toString()
            if (!t.isNullOrBlank() && prefs.getBoolean("clipon", true)) pushList("clips", t, 20)
        } catch (e: Exception) { }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- live voice typing (text appears while you speak) ----------
    private var recognizer: SpeechRecognizer? = null
    private var voiceOn = false
    private var micView: View? = null
    private var voiceErrors = 0      // consecutive hard errors
    private var voiceSilent = 0      // consecutive rounds where nothing was heard
    private var voiceNeedSpace = false
    private var voiceCap = false

    // ---- mixed Bangla + English voice ----
    private var mixMap: Map<String, String>? = null
    private val wordTok = Regex("[\\p{L}\\p{M}]+")
    private fun mixOn() = prefs.getBoolean("mixvoice", true)

    /** English words that the recognizer wrote in Bangla letters (ফোন, মেসেজ...) -> English spelling */
    private fun mixFix(s: String): String {
        var m = mixMap
        if (m == null) {
            val mm = HashMap<String, String>()
            try {
                assets.open("bn_en_map.txt").bufferedReader().useLines { ls ->
                    for (ln in ls) {
                        val p = ln.trim().split(" ")
                        if (p.size >= 2) mm[p[0]] = p.drop(1).joinToString(" ")
                    }
                }
            } catch (e: Exception) { }
            mixMap = mm; m = mm
        }
        if (m.isEmpty()) return s
        return wordTok.replace(s) { m[it.value] ?: it.value }
    }

    /** best candidate: in mixed mode prefer one that really contains both Bangla and English letters */
    private fun bestOf(r: Bundle?): String? {
        val l = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return null
        if (l.size > 1 && mixOn()) {
            for (c in l) {
                val bn = c.any { it in '\u0980'..'\u09FF' }
                val en = c.any { it in 'a'..'z' || it in 'A'..'Z' }
                if (bn && en) return c
            }
        }
        return l.firstOrNull()
    }
    private var voiceReady = false
    private var warmConn: ServiceConnection? = null   // keeps the speech service process alive while the keyboard is open

    private val restartListen = Runnable { listenNow() }
    private val stopGuard = Runnable {
        try { recognizer?.cancel() } catch (e: Exception) { }
        currentInputConnection?.finishComposingText()
    }

    // spoken punctuation: say "কমা" / "দাঁড়ি" / "নতুন লাইন" (or "comma", "full stop", "new line")
    private fun cmds(list: List<Pair<String, String>>, ic: Boolean): List<Pair<Regex, String>> = list.map { (p, s) ->
        val core = "(?<![\\p{L}\\p{M}])" + Regex.escape(p) + "(?![\\p{L}\\p{M}])"
        val re = if (s == "\n") "\\s*" + core + "\\s*" else "\\s*" + core
        (if (ic) Regex(re, RegexOption.IGNORE_CASE) else Regex(re)) to s
    }

    private val cmdBn by lazy {
        cmds(listOf(
            "প্রশ্নবোধক চিহ্ন" to "?", "পূর্ণচ্ছেদ" to "।",
            "\u09A6\u09BE\u0981\u09DC\u09BF" to "।", "\u09A6\u09BE\u0981\u09A1\u09BC\u09BF" to "।",
            "\u09A6\u09BE\u09DC\u09BF" to "।", "\u09A6\u09BE\u09A1\u09BC\u09BF" to "।",
            "কমা" to ",", "নতুন লাইন" to "\n"
        ), false)
    }
    private val cmdEn by lazy {
        cmds(listOf("question mark" to "?", "full stop" to ".", "period" to ".", "comma" to ",", "new line" to "\n"), true)
    }

    private fun voiceText(raw: String): String {
        var s = raw
        if (lang == "bn" && mixOn()) s = mixFix(s)
        for ((re, sym) in (if (lang == "bn") cmdBn else cmdEn)) s = s.replace(re, sym)
        s = s.trim { it == ' ' }
        if (s.isEmpty()) return s
        if (voiceCap) s = s.replaceFirstChar { it.uppercaseChar() }
        if (voiceNeedSpace && s[0] != '\n' && s[0] !in ",.?!।") s = " " + s
        return s
    }

    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {
            // the recognizer is really listening now: mic turns green + tiny tick = "you can speak"
            if (!voiceOn) return
            if (!voiceReady) { voiceReady = true; setMic(VOICE_GREEN); waveView?.color = VOICE_GREEN; buzz() }
        }
        override fun onBeginningOfSpeech() { voiceSilent = 0 }
        override fun onRmsChanged(v: Float) {
            if (!voiceOn) return
            waveView?.push(v)       // সাউন্ড-ওয়েভ আওয়াজের সাথে নড়ে (মাইক বোতাম আর ফোলে-কমে না)
        }
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onPartialResults(r: Bundle?) {
            val t = bestOf(r) ?: return
            if (t.isEmpty()) return
            val s = voiceText(t)
            if (s.isNotEmpty()) currentInputConnection?.setComposingText(s, 1)
        }

        override fun onResults(r: Bundle?) {
            h.removeCallbacks(stopGuard)
            deliver(r)
            if (voiceOn) h.post(restartListen)   // keep listening with no gap (fewer lost words)
        }

        // Android 13+: one continuous session, every finished sentence arrives here (no restart gap at all)
        override fun onSegmentResults(r: Bundle) { deliver(r) }

        override fun onEndOfSegmentedSession() {
            h.removeCallbacks(stopGuard)
            currentInputConnection?.finishComposingText()
            lastBase = null
            if (voiceOn) h.post(restartListen)
        }

        override fun onError(e: Int) {
            h.removeCallbacks(stopGuard)
            currentInputConnection?.finishComposingText()
            if (!voiceOn) return
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    voiceSilent++
                    if (voiceSilent >= 4) { stopVoice(); toast("কথা শোনা যায়নি — আবার মাইক চাপুন") }
                    else h.postDelayed(restartListen, 100)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    try { recognizer?.cancel() } catch (x: Exception) { }
                    h.postDelayed(restartListen, 400)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stopVoice(); askMicPermission() }
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> { stopVoice(); toast("ইন্টারনেট চেক করুন") }
                SpeechRecognizer.ERROR_AUDIO -> { stopVoice(); toast("মাইক ব্যবহার করা যাচ্ছে না (অন্য অ্যাপ ব্যবহার করছে?)") }
                12, 13 -> { stopVoice(); toast("এই ভাষার ভয়েস টাইপ এই ফোনে নেই") }
                else -> {
                    // e.g. ERROR_CLIENT: rebuild the recognizer a couple of times before giving up
                    voiceErrors++
                    if (voiceErrors <= 2) {
                        try { recognizer?.destroy() } catch (x: Exception) { }
                        recognizer = null
                        h.postDelayed(restartListen, 300)
                    } else { stopVoice(); toast("ভয়েস টাইপ চালু করা যায়নি ($e)") }
                }
            }
        }
    }

    /** commit the final text of a finished sentence / segment */
    private fun deliver(r: Bundle?) {
        val t = bestOf(r)
        val ic = currentInputConnection
        val s = if (t.isNullOrEmpty()) "" else voiceText(t)
        if (s.isNotEmpty() && ic != null) {
            ic.commitText(if (s.endsWith("\n")) s else s + " ", 1)
            for (t in wordTok.findAll(s)) learnWord(t.value, true)
            voiceErrors = 0; voiceSilent = 0
        } else {
            ic?.finishComposingText()
        }
        lastBase = null
        prepRound()
    }

    /** decide spacing / capital letter for the next piece of text (before any partial text is shown) */
    private fun prepRound() {
        val b = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        voiceNeedSpace = b.isNotEmpty() && !b.last().isWhitespace() && b.last() !in "([{"
        voiceCap = lang == "en" && (b.isBlank() || b.trimEnd().last() in ".!?")
    }

    /** idle mic circle: the key colour made softer (less white glow) */
    private fun micIdle(): Int {
        val c = th.keyAlt
        return (c and 0x00FFFFFF) or ((((c ushr 24) * 0.5f).toInt()) shl 24)
    }

    /** মাইক বোতামের গোল: রিং (২৮dp) সবসময় থাকে; ভয়েস চালু হলে হলুদ/সবুজ গোল রিংয়ের সাথে লেগে ভেতরে বসে */
    private fun micBg(color: Int, ring: Boolean = false): android.graphics.drawable.Drawable {
        val ringG = GradientDrawable().also {
            it.shape = GradientDrawable.OVAL
            it.setStroke(dp(1), (th.accent and 0x00FFFFFF) or 0x99000000.toInt())
            if (ring) it.setColor(color)          // সাধারণ অবস্থা: রিংয়ের ভেতরে নরম রঙ
        }
        if (ring) return InsetDrawable(ringG, 0)
        val fill = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(color) }
        val ld = android.graphics.drawable.LayerDrawable(arrayOf(ringG, fill))
        ld.setLayerInset(1, dp(1), dp(1), dp(1), dp(1))   // হলুদ/সবুজ গোল রিংয়ের ভেতরে, রিংয়ের সাথে লেগে (রিংয়ের পুরুত্ব = dp(1))
        return ld
    }

    /** ভয়েস চালু থাকলে আইকন সাদা (রঙিন গোলের ওপর), বন্ধ থাকলে থিমের অ্যাকসেন্ট রঙে */
    private fun micIcon(on: Boolean) {
        (micView as? IconView)?.let { it.color = if (on) 0xFFFFFFFF.toInt() else th.accent; it.invalidate() }
    }

    private fun setMic(color: Int) {
        micView?.background = micBg(color)
        micIcon(true)
    }

    /** Create the recognizer early and wake up the speech service so the first mic tap does not wait for it. */
    private fun warmVoice() {
        if (voiceOn || warmConn != null || noLearn) return
        try {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(recListener)
            }
            var cn: ComponentName? = null
            try {
                cn = android.provider.Settings.Secure.getString(contentResolver, "voice_recognition_service")
                    ?.let { ComponentName.unflattenFromString(it) }
            } catch (e: Exception) { }
            if (cn == null) {
                cn = packageManager.queryIntentServices(Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0)
                    .firstOrNull()?.serviceInfo?.let { ComponentName(it.packageName, it.name) }
            }
            if (cn == null) return
            val conn = object : ServiceConnection {
                override fun onServiceConnected(n: ComponentName?, b: IBinder?) {}
                override fun onServiceDisconnected(n: ComponentName?) {}
            }
            val ok = bindService(Intent(android.speech.RecognitionService.SERVICE_INTERFACE).setComponent(cn), conn, Context.BIND_AUTO_CREATE)
            if (ok) warmConn = conn else try { unbindService(conn) } catch (e: Exception) { }
        } catch (e: Exception) { }
    }

    private fun coolVoice() {
        val c = warmConn ?: return
        warmConn = null
        try { unbindService(c) } catch (e: Exception) { }
    }

    private fun askMicPermission() {
        startActivity(Intent(this, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun listenNow() {
        if (!voiceOn) return
        try {
            prepRound()

            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(recListener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "bn") "bn-BD" else "en-US")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            if (Build.VERSION.SDK_INT >= 33) i.putExtra("android.speech.extra.SEGMENTED_SESSION", true)
            if (mixOn()) {
                // also understand the other language (Android 13+ / Google speech service)
                i.putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf(if (lang == "bn") "en-US" else "bn-BD"))
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(i)
        } catch (e: Exception) {
            stopVoice()
            toast("ভয়েস টাইপ পাওয়া যাচ্ছে না")
        }
    }

    private fun startVoice() {
        if (voiceOn) { stopVoice(true); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            askMicPermission(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে ভয়েস রিকগনিশন সার্ভিস নেই (Google অ্যাপ / Speech Services লাগবে)")
            return
        }
        h.removeCallbacks(stopGuard)
        flush()
        voiceOn = true; voiceErrors = 0; voiceSilent = 0; voiceReady = false
        setMic(0xFFE0A100.toInt())      // amber = starting; turns green when it is really listening
        showVoiceBar(true)
        listenNow()
    }

    /** finish = true: user tapped the mic, let the recognizer deliver its last words first. */
    private fun stopVoice(finish: Boolean = false) {
        val was = voiceOn
        voiceOn = false; voiceErrors = 0; voiceSilent = 0; voiceReady = false
        h.removeCallbacks(restartListen)
        micView?.let {
            it.scaleX = 1f; it.scaleY = 1f
            it.background = micBg(micIdle(), true)
        }
        micIcon(false)
        showVoiceBar(false)
        if (finish && was) {
            try { recognizer?.stopListening() } catch (e: Exception) { }
            h.removeCallbacks(stopGuard); h.postDelayed(stopGuard, 1800)
        } else {
            h.removeCallbacks(stopGuard)
            try { recognizer?.stopListening(); recognizer?.cancel() } catch (e: Exception) { }
            currentInputConnection?.finishComposingText()
        }
    }

    /** any normal typing key stops dictation first (so typed keys never overwrite live voice text) */
    private fun voiceOff() { if (voiceOn) stopVoice() }

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        Words.load(this)
        loadUd()
        loadBi()
        clipCm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipCm?.addPrimaryClipChangedListener(clipL)
    }

    override fun onDestroy() {
        voiceOn = false
        h.removeCallbacksAndMessages(null); sugPending = false
        try { clipCm?.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { }
        try { recognizer?.destroy() } catch (e: Exception) { }
        coolVoice()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        root = r
        applyPrefs()
        mode = layoutFor(lang)
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        comp.setLength(0); lastBase = null; tools = false; panel = ""
        recentCache = null; lastFin = null
        applyPrefs()
        val inp = info?.inputType ?: 0
        val cls = inp and InputType.TYPE_MASK_CLASS
        val va = inp and InputType.TYPE_MASK_VARIATION
        noLearn = (cls == InputType.TYPE_CLASS_TEXT && (va == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                va == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || va == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                (inp and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && va == InputType.TYPE_NUMBER_VARIATION_PASSWORD) ||
                ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        warmVoice()
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) "num" else layoutFor(lang)
        caps = false
        shift = mode == "en" && (currentInputConnection?.getTextBeforeCursor(1, 0)?.isEmpty() ?: false)
        // only rebuild all the key views when something really changed (keyboard opens much faster)
        if ((root?.childCount ?: 0) == 0 || sig() != lastSig) build()
        else { refreshShift(); refreshKar(); updateSuggestions() }
    }

    private fun sig(): Int = java.util.Objects.hash(
        prefs.all.filterKeys { k -> k != "clips" && k != "recent" }.hashCode(), mode, tools, panel, voiceOn, resources.configuration.orientation
    )

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (root != null) { applyPrefs(); build() }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        hidePop()
        if (voiceOn) stopVoice()
        try { recognizer?.cancel() } catch (e: Exception) { }
        coolVoice()
        if (udDirty) saveUd()
        if (biDirty) saveBi()
        h.removeCallbacksAndMessages(null); sugPending = false   // also stops a stuck backspace-repeat
        super.onFinishInputView(finishingInput)
    }

    override fun onFinishInput() {
        comp.setLength(0)
        super.onFinishInput()
    }

    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) {
        super.onUpdateSelection(a, b, c, d, e, f)
        if (comp.isNotEmpty() && (e == -1 || f == -1)) comp.setLength(0)
        updateSuggestions()
    }

    private fun applyPrefs() {
        th = Themes.get(prefs.getString("theme", "dark") ?: "dark", prefs)
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val hp = prefs.getInt(if (land) "kh_l" else "kh_p", 100)
        keyH = (prefs.getInt("keyh", 48) * hp / 100f).toInt().coerceAtLeast(20)
        padB = dp(keyH) * prefs.getInt(if (land) "pad_l" else "pad_p", 0) / 100
        fs = prefs.getInt("fscale", 100) / 100f
        gap = prefs.getInt("gap", 2)
        flat = prefs.getBoolean("flat", false)
        lang = prefs.getString("lang", "bn") ?: "bn"
        if (prefs.contains("bigram")) prefs.edit().remove("bigram").apply()
        if (!biDirty && !biFile().exists()) bi?.clear()
        if (!udDirty && !udFile().exists()) { ud?.clear(); udPending.clear() }
    }

    private fun layoutFor(l: String): String =
        if (l == "en") "en" else if (prefs.getString("bnlayout", "classic") == "phonetic") "bnp" else "bn"

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun buzz() {
        if (prefs.getBoolean("vibrate", true)) {
            val st = prefs.getString("vib_str", "sys") ?: "sys"
            if (st == "sys") root?.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            else try {
                val (ms, amp) = when (st) { "light" -> 8L to 50; "strong" -> 40L to 255; else -> 20L to 130 }
                val vb = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) vb.vibrate(VibrationEffect.createOneShot(ms, amp))
                else vb.vibrate(ms)
            } catch (e: Exception) { }
        }
        if (prefs.getBoolean("keysound", false)) try {
            val v = prefs.getString("snd_vol", "sys") ?: "sys"
            val pct = v.toIntOrNull()
            val sysOn = android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SOUND_EFFECTS_ENABLED, 1) == 1
            if (pct == null && sysOn) {
                (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).playSoundEffect(android.media.AudioManager.FX_KEYPRESS_STANDARD)
            } else clickSound((pct ?: 60) / 100f)   // own short click: works even if the phone's "touch sounds" are off
        } catch (e: Exception) { }
    }

    private var clickTrack: android.media.AudioTrack? = null

    private fun clickSound(vol: Float) {
        try {
            if (clickTrack == null) {
                val sr = 22050
                val n = sr * 14 / 1000
                val d = ShortArray(n) { i ->
                    val t = i / sr.toDouble()
                    (Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 380) * 20000).toInt().toShort()
                }
                val at = android.media.AudioTrack.Builder()
                    .setAudioAttributes(android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr).setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(d.size * 2)
                    .setTransferMode(android.media.AudioTrack.MODE_STATIC).build()
                at.write(d, 0, d.size)
                clickTrack = at
            }
            val t = clickTrack ?: return
            t.stop(); t.reloadStaticData(); t.setVolume(vol.coerceIn(0f, 1f)); t.play()
        } catch (e: Exception) { }
    }

    // ---------- key pop-up (magnified preview while a key is pressed) ----------
    private var pop: PopupWindow? = null

    private fun hidePop() { try { pop?.dismiss() } catch (e: Exception) { }; pop = null }

    private fun showPop(v: View, label: String) {
        hidePop()
        try {
            val base = th.grad?.firstOrNull() ?: th.bg
            val k = if (android.graphics.Color.alpha(th.key) == 255) th.key else {
                val a = android.graphics.Color.alpha(th.key) / 255f
                fun m(x: Int, y: Int) = (x * (1 - a) + y * a).toInt()
                android.graphics.Color.rgb(
                    m(android.graphics.Color.red(base), android.graphics.Color.red(th.key)),
                    m(android.graphics.Color.green(base), android.graphics.Color.green(th.key)),
                    m(android.graphics.Color.blue(base), android.graphics.Color.blue(th.key)))
            }
            val t = TextView(this)
            t.text = label; t.textSize = 28f; t.gravity = Gravity.CENTER; t.setTextColor(th.text)
            val bgd = GradientDrawable(); bgd.setColor(k); bgd.cornerRadius = dp(12).toFloat()
            bgd.setStroke(dp(1), th.accent)
            t.background = bgd
            val w = maxOf(v.width + dp(14), dp(56)); val hh = dp(64)
            val pw = PopupWindow(t, w, hh)
            pw.isTouchable = false; pw.isFocusable = false; pw.isClippingEnabled = false
            val loc = IntArray(2); v.getLocationOnScreen(loc)
            pw.showAtLocation(v, Gravity.NO_GRAVITY, loc[0] + (v.width - w) / 2, loc[1] - hh - dp(4))
            pop = pw
        } catch (e: Exception) { pop = null }
    }

    /** key look drawn with an inset: the touch area fills the whole cell, so taps between keys are never lost (fewer mis-touches) */
    private fun keyBgI(color: Int): android.graphics.drawable.Drawable =
        if (th.neu) InsetDrawable(neuKey(color), dp(gap), dp(2), dp(gap), dp(2))
        else InsetDrawable(keyBg(color), dp(gap), dp(3), dp(gap), dp(3))

    /** soft raised key (like the Soft White / Soft Black screenshot): thin light edge all round, hard offset shadow bottom-right */
    private fun neuKey(face: Int): android.graphics.drawable.Drawable {
        val lightFace = android.graphics.Color.luminance(face) > 0.5f
        fun mix(a: Int, b: Int, t: Float): Int {
            fun m(x: Int, y: Int) = (x + (y - x) * t).toInt()
            return android.graphics.Color.rgb(
                m(android.graphics.Color.red(a), android.graphics.Color.red(b)),
                m(android.graphics.Color.green(a), android.graphics.Color.green(b)),
                m(android.graphics.Color.blue(a), android.graphics.Color.blue(b)))
        }
        val white = 0xFFFFFFFF.toInt(); val black = 0xFF000000.toInt()
        val edge = if (lightFace) mix(face, white, 0.85f) else mix(face, white, 0.13f)
        val sh = if (lightFace) mix(face, black, 0.24f) else black
        val ox = if (lightFace) dp(2) else dp(3); val oy = if (lightFace) dp(3) else dp(4)
        val r = dp(th.radius).toFloat()
        val shD = GradientDrawable(); shD.setColor(sh); shD.cornerRadius = r
        val faceD = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(if (lightFace) mix(face, white, 0.25f) else mix(face, white, 0.03f), face))
        faceD.cornerRadius = r
        faceD.setStroke(maxOf(1, dp(1)), edge)
        val ld = android.graphics.drawable.LayerDrawable(arrayOf<android.graphics.drawable.Drawable>(shD, faceD))
        ld.setLayerInset(0, ox, oy, 0, 0)
        ld.setLayerInset(1, 0, 0, ox, oy)
        return ld
    }

    private fun keyBg(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(th.radius).toFloat()
        if (th.stroke != 0) g.setStroke(dp(1), th.stroke)
        return g
    }

    private fun getList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("\u0001").filter { it.isNotEmpty() }

    private fun pushList(k: String, v: String, max: Int) {
        val l = getList(k).toMutableList()
        l.remove(v); l.add(0, v)
        if (k == "recent") recentCache = null
        prefs.edit().putString(k, l.take(max).joinToString("\u0001")).apply()
    }

    // ---- block words: never suggested, never saved ----
    private var blkRaw = ""
    private var blkSet: Set<String> = emptySet()
    private fun isBlocked(w: String): Boolean {
        val raw = prefs.getString("blockwords", "") ?: ""
        if (raw != blkRaw) { blkRaw = raw; blkSet = raw.split("\u0001").filter { it.isNotEmpty() }.toSet() }
        return blkSet.isNotEmpty() && blkSet.contains(w.lowercase())
    }

    private fun addRecent(w: String) {
        if (isBlocked(w)) return
        if (!noLearn && w.length >= 2) pushList("recent", w, 40)
        learnWord(w, false)
        learnBigram(w)
    }

    private fun recent(): List<String> = recentCache ?: getList("recent").also { recentCache = it }

    private fun key(
        label: String, w: Float = 1f, alt: Boolean = false, size: Float = 20f,
        long: (() -> Unit)? = null, hint: String? = null, holdMs: Long = 300L, tap: () -> Unit
    ): TextView {
        val t = IconKey(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(th.text)
        if (label.isNotEmpty() && label[0] in '\u0980'..'\u09FF') LetterStyle.bnTypeface(prefs.getString("bnstyle", "normal"))?.let { t.typeface = it }
        t.textSize = size * th.scale * fs
        t.background = if (flat && !alt) null else keyBgI(if (alt) th.keyAlt else th.key)
        if (hint != null && prefs.getBoolean("hints", true)) {
            t.hintText = hint; t.hintColor = th.dim; t.hintSize = dp(11).toFloat()
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        lp.setMargins(0, 0, 0, 0)
        t.layoutParams = lp
        t.setOnClickListener { buzz(); tap() }   // only reached by accessibility (TalkBack); touches are handled below
        val lg: (() -> Unit)? = long ?: (if (hint != null) ({ commit(hint) }) else null)
        var done = false
        val showPopup = label.isNotBlank() && label.length <= 2 && prefs.getBoolean("keypopup", true)
        val tapRun = Runnable { tap() }   // posted (not called inline) so build() never runs in the middle of a touch dispatch
        val lpRun = Runnable { done = true; buzz(); lg?.invoke() }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.55f; done = false
                    if (showPopup) showPop(v, t.text.toString())
                    if (lg == null) { done = true; buzz(); h.post(tapRun) }      // no long-press on this key: type instantly on touch-down
                    else h.postDelayed(lpRun, holdMs)
                }
                MotionEvent.ACTION_MOVE -> if (lg != null && !done) {
                    val s = dp(14)
                    if (e.x < -s || e.y < -s || e.x > v.width + s || e.y > v.height + s) { done = true; h.removeCallbacks(lpRun) }
                }
                MotionEvent.ACTION_UP -> {
                    v.alpha = 1f; if (showPopup) hidePop()
                    if (lg != null) { h.removeCallbacks(lpRun); if (!done) { done = true; buzz(); h.post(tapRun) } }
                }
                MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; if (showPopup) hidePop(); h.removeCallbacks(lpRun); done = true }
            }
            true
        }
        return t
    }

    private fun ik(kind: String, w: Float = 1f, alt: Boolean = false, long: (() -> Unit)? = null, holdMs: Long = 300L, tap: () -> Unit): IconKey {
        val t = key("", w, alt, 20f, long, null, holdMs, tap) as IconKey
        t.kind = kind
        return t
    }

    private fun rowOf(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyH))
        for (x in v) l.addView(x)
        return l
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        return v
    }

    private fun backKey(w: Float): TextView {
        val t = ik("back", w, true) { }
        val rep = object : Runnable {
            override fun run() { doBackspace(); h.postDelayed(this, 45) }
        }
        t.setOnClickListener(null)
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.alpha = 0.55f; buzz(); doBackspace(); h.postDelayed(rep, 350) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; h.removeCallbacks(rep) }
            }
            true
        }
        return t
    }

    // ---------- build UI ----------
    private fun build() {
        val r = root ?: return
        r.removeAllViews(); letters.clear(); karViews.clear(); sug.clear(); shiftView = null; voiceBox = null; waveView = null; sugScroll = null
        r.orientation = LinearLayout.VERTICAL
        val g = th.grad
        r.background = if (g != null) GradientDrawable(if (th.vert) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.TL_BR, g)
        else GradientDrawable().also { it.setColor(th.bg) }
        r.setPadding(dp(3), dp(2), dp(3), dp(2) + padB)
        if (mode != "num") r.addView(topBar())
        if (panel.isNotEmpty()) {
            r.addView(panelView())
        } else {
            when (mode) {
                "bn" -> bnLayout(r)
                "sym" -> symLayout(r)
                "num" -> numLayout(r)
                else -> qwerty(r)
            }
            if (mode != "num") r.addView(bottomRow())
        }
        refreshKar(); refreshShift(); updateSuggestions()
        lastSig = sig()
    }

    private fun tbtn(label: String, w: Float = 0f, f: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label; t.textSize = 20f; t.gravity = Gravity.CENTER; t.setTextColor(th.text)
        t.layoutParams = if (w > 0f) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        else LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT)
        t.setOnClickListener { buzz(); f() }
        return t
    }

    private fun ibtn(kind: String, w: Float = 0f, f: () -> Unit): IconView {
        val v = IconView(this, kind, th.text)
        v.layoutParams = if (w > 0f) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        else LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT)
        v.setOnClickListener { buzz(); f() }
        v.setOnTouchListener { x, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> x.alpha = 0.5f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.alpha = 1f
            }
            false
        }
        return v
    }

    private fun topBar(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(33))
        if (tools) {
            l.addView(ibtn("grid", 1f) { tools = false; build() }.also { it.color = th.accent })
            l.addView(ibtn("clip", 1f) { panel = "clip"; tools = false; build() })
            l.addView(ibtn("emoji", 1f) { panel = "emoji"; tools = false; build() })
            l.addView(ibtn("sticker", 1f) { panel = "sticker"; tools = false; build() })
            l.addView(ibtn("num", 1f) { flush(); mode = "num"; tools = false; build() })
            l.addView(ibtn("lang", 1f) { toggleBnLayout() })
            l.addView(ibtn("gear", 1f) { openSettings() })
        } else {
            l.addView(ibtn("grid") { tools = true; build() })
            // ৮টি সাজেশন একটি আড়াআড়ি স্ক্রল-বারে; ডানে-বামে সোয়াইপ করলে সবগুলো দেখা যায়
            val sc = HorizontalScrollView(this)
            sc.isHorizontalScrollBarEnabled = false
            sc.overScrollMode = View.OVER_SCROLL_NEVER
            sc.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            for (i in 0 until SUG_N) {
                val t = TextView(this)
                t.gravity = Gravity.CENTER; t.textSize = 17f; t.setTextColor(th.text)
                t.maxLines = 1
                t.setPadding(dp(12), 0, dp(12), 0)
                t.minWidth = dp(56)
                t.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
                t.setOnClickListener { pickSuggestion(t.text.toString()) }
                sug.add(t); row.addView(t)
            }
            sc.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            sugScroll = sc
            l.addView(sc)
            val vb = LinearLayout(this)
            vb.orientation = LinearLayout.HORIZONTAL
            vb.gravity = Gravity.CENTER
            vb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            val vt = TextView(this)
            vt.text = "বলুন"
            vt.textSize = 17f; vt.setTextColor(th.text)
            vt.setPadding(0, 0, dp(10), 0)
            val wv = WaveView(this)
            wv.layoutParams = LinearLayout.LayoutParams(dp(84), dp(22))
            wv.color = if (voiceOn && voiceReady) VOICE_GREEN else 0xFF9E9E9E.toInt()
            vb.addView(vt); vb.addView(wv)
            vb.visibility = if (voiceOn) View.VISIBLE else View.GONE
            sc.visibility = if (voiceOn) View.GONE else View.VISIBLE
            voiceBox = vb; waveView = wv
            l.addView(vb)
        }
        val mic = ibtn("mic") { startVoice() }
        micView = mic
        mic.background = if (voiceOn) micBg(if (voiceReady) 0xFF1B8A3E.toInt() else 0xFFE0A100.toInt()) else micBg(micIdle(), true)
        mic.color = if (voiceOn) 0xFFFFFFFF.toInt() else th.accent
        val mlp = LinearLayout.LayoutParams(dp(28), dp(28))
        mlp.setMargins(dp(4), 0, dp(4), 0)
        mic.layoutParams = mlp
        l.addView(mic)
        return l
    }

    private fun bnLayout(r: LinearLayout) {
        val kr = ArrayList<View>()
        for (i in 0 until 10) {
            // স্বরবর্ণ সারি: ছোট চাপে আগের মতো; কিছুক্ষণ ধরে রাখলে শুধু কার-চিহ্ন (আ-কার, ই-কার…) বসে। "অ"-র কার নেই।
            val t = key("", 1f, false, 20f, if (kars[i].isEmpty()) null else ({ karHold(i) }), null, 500L) { karTap(i) }
            t.setTextColor(th.text)
            karViews.add(t); kr.add(t)
        }
        r.addView(rowOf(*kr.toTypedArray()))
        for (i in 0 until 3) r.addView(rowOf(*bnRows[i].map { bnKey(it) }.toTypedArray()))
        val last = ArrayList<View>()
        for (c in bnRows[3]) last.add(bnKey(c, if (c == "ং" || c == "ঃ" || c == "ঁ") 0.8667f else 1f))
        last.add(backKey(1.4f))
        r.addView(rowOf(*last.toTypedArray()))
    }

    private fun bnKey(c: String, w: Float = 1f): TextView {
        val isBase = c != "ং" && c != "ঃ" && c != "ঁ"
        return key(c, w, size = 22f) {
            commit(c)
            if (isBase) { lastBase = c; refreshKar() }
        }
    }

    private fun karLabel(i: Int): String { val b = lastBase; return if (b == null) vowels[i] else b + kars[i] }

    private fun refreshKar() {
        for (i in karViews.indices) {
            val s = karLabel(i)
            if (karViews[i].text.toString() != s) karViews[i].text = s
        }
    }

    /** ধরে রাখা: আগে ব্যঞ্জন লেখা থাকলে ছোট চাপের মতোই (ব্যঞ্জন+কার); না থাকলে শুধু কার-চিহ্নটি বসে */
    private fun karHold(i: Int) {
        if (lastBase != null) { karTap(i); return }
        voiceOff()
        val ic = currentInputConnection ?: return
        ic.commitText(kars[i], 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun karTap(i: Int) {
        voiceOff()
        val ic = currentInputConnection ?: return
        val lab = karLabel(i)
        val b = lastBase
        if (b != null) ic.deleteSurroundingText(b.length, 0)
        ic.commitText(lab, 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun qwerty(r: LinearLayout) {
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val digits = "1234567890"
        r.addView(rowOf(*rows[0].mapIndexed { i, c -> letterKey(c, digits[i].toString()) }.toTypedArray()))
        val r2 = ArrayList<View>()
        r2.add(spacer(0.5f))
        for ((i, c) in rows[1].withIndex()) r2.add(letterKey(c, "@#\$%&-+()"[i].toString()))
        r2.add(spacer(0.5f))
        r.addView(rowOf(*r2.toTypedArray()))
        val r3 = ArrayList<View>()
        val sh = ik("shift", 1.5f, true) {
            val now = SystemClock.uptimeMillis()
            if (now - lastShiftTap < 350) { caps = true; shift = true }
            else if (caps) { caps = false; shift = false }
            else shift = !shift
            lastShiftTap = now
            refreshShift()
        }
        shiftView = sh
        r3.add(sh)
        for ((i, c) in rows[2].withIndex()) r3.add(letterKey(c, "*\"':;!?"[i].toString()))
        r3.add(backKey(1.5f))
        r.addView(rowOf(*r3.toTypedArray()))
    }

    private fun letterKey(c: Char, digit: String?): TextView {
        val lg: (() -> Unit)? = if (digit != null) ({ commit(digit) }) else null
        val t = key(c.toString(), 1f, false, 20f, null, digit) { typeLetter(c) }
        letters.add(Pair(t, c.toString()))
        return t
    }

    private fun typeLetter(c: Char) {
        val ch = if (shift) c.uppercaseChar() else c
        if (mode == "bnp") phon(ch.toString())
        else if (mode == "en") commit(LetterStyle.apply(prefs.getString("enstyle", "normal") ?: "normal", ch.toString()))
        else commit(ch.toString())
        if (shift && !caps) { shift = false; refreshShift() }
    }

    private fun refreshShift() {
        for (p in letters) p.first.text = if (shift) p.second.uppercase() else p.second
        val s = shiftView ?: return
        val on = shift || caps
        s.background = keyBgI(if (on) th.accent else th.keyAlt)
        s.setTextColor(if (on) th.onAccent else th.text)
        (s as? IconKey)?.kind = if (caps) "caps" else if (shift) "shiftOn" else "shift"
        s.invalidate()
    }

    private fun symLayout(r: LinearLayout) {
        val d = if (lang == "bn") "১২৩৪৫৬৭৮৯০" else "1234567890"
        r.addView(strRow(d))
        r.addView(strRow("@#\$%&-+()/"))
        val l = ArrayList<View>()
        for (ch in "=*\"':;!?।") l.add(key(ch.toString()) { commit(ch.toString()) })
        l.add(backKey(1f))
        r.addView(rowOf(*l.toTypedArray()))
    }

    private fun strRow(s: String): LinearLayout =
        rowOf(*s.map { ch -> key(ch.toString()) { commit(ch.toString()) } }.toTypedArray())

    private fun bottomRow(): LinearLayout {
        val sym = mode == "sym"
        val v = ArrayList<View>()
        v.add(key(if (sym) "ABC" else if (lang == "bn") "?১২৩" else "?123", 1.5f, true, 15f,
            if (sym) null else ({ flush(); mode = "sym"; build() })) {
            flush(); mode = if (sym) layoutFor(lang) else "num"; build()
        })
        v.add(ik("emoji", 1f, false, { panel = "emoji"; build() }) { commit(",") }.also {
            it.iconDy = dp(3).toFloat(); it.hintBaseline = dp(12).toFloat()   // smiley a bit lower, comma up in the corner (clear of the face)
            it.hintText = ","; it.hintColor = th.text; it.hintSize = dp(19).toFloat(); it.hintBold = true
            it.hintDx = 1.5f * resources.displayMetrics.density   // কমা ইমোজির দিকে ১.৫dp কাছে
        })
        v.add(ik("globe", 1f, false) { switchLang() })
        val label = when (mode) { "bn" -> "বাংলা"; "bnp" -> "বাংলা (ফোনেটিক)"; "en" -> "English"; else -> "" }
        v.add(key(label, if (mode == "bn") 3.2f else 4f, false, 14f, { imePicker() }) { onSpace() }.also { if (th.neu) it.setTextColor(th.dim) })
        if (mode == "bn") {
            v.add(key("\u25CC\u09CD", 1f, false, 18f, { commit("\u09CD\u09AF") }) { commit("\u09CD") })
        }
        val dot = if (lang == "bn") "।" else "."
        v.add(key(dot, 1f, false, 20f) { commit(dot) })
        val enter = ik("enter", 1.5f, false) { enterKey() }
        val ea = prefs.getBoolean("enteraccent", true)
        enter.background = keyBgI(if (ea) th.accent else th.keyAlt)
        enter.setTextColor(if (ea) th.onAccent else th.text)
        v.add(enter)
        return rowOf(*v.toTypedArray())
    }

    // ---------- number pad ----------
    // 5 columns:  [ + * / ] [1 4 7] [2 5 8 0] [3 6 9] [ % space back ok ]
    private val bnDigits = "০১২৩৪৫৬৭৮৯"

    private fun numRow(vararg v: View): LinearLayout {
        val l = rowOf(*v)
        l.layoutParams.height = dp(keyH + 10)
        return l
    }

    /** plain symbol key (no tile), like the left / right columns of the number pad */
    private fun nsym(label: String, w: Float, hint: String? = null): TextView {
        val t = key(label, w, false, 24f, null, hint) { commit(label) }
        t.background = null
        t.isSingleLine = true
        return t
    }

    /** digit tile; in Bangla mode a small Bangla digit is shown and typed on long-press */
    private fun ndig(d: String, w: Float = 1f): TextView {
        val bn = if (lang == "bn") bnDigits[d[0] - '0'].toString() else null
        val t = if (bn != null && prefs.getString("bndigits", "en") == "bn") key(bn, w, false, 26f, null, d) { commit(bn) }
        else key(d, w, false, 26f, null, bn) { commit(d) }
        t.isSingleLine = true
        return t
    }

    private fun roundOk(ok: View) {
        // perfect circle in the accent colour, whatever the cell size is
        ok.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            val w = r - l; val hh = b - t
            val d = minOf(w, hh)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(th.accent)
            v.background = InsetDrawable(g, maxOf(0, (w - d) / 2), maxOf(0, (hh - d) / 2), maxOf(0, (w - d) / 2), maxOf(0, (hh - d) / 2))
        }
    }

    /** put a key into a vertical column: full width, equal share of the height */
    private fun <T : View> vcell(v: T): T {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        lp.setMargins(0, 0, 0, 0)
        v.layoutParams = lp
        return v
    }

    private fun vcol(w: Float, vararg v: View): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        for (x in v) c.addView(x)
        return c
    }

    // left column: 4 symbols (+ - * /) share the height of the 3 digit rows
    private fun numLayout(r: LinearLayout) {
        val cs = 0.85f   // side columns are a little narrower than the digit columns
        val ok = ik("check", cs, false) { enterKey() }
        ok.setTextColor(th.onAccent)
        roundOk(ok)
        val bk = backKey(cs)
        bk.background = null
        val sp = ik("space", cs, false) { onSpace() }
        sp.background = null

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 3f)
        mid.addView(numRow(ndig("1"), ndig("2"), ndig("3")))
        mid.addView(numRow(ndig("4"), ndig("5"), ndig("6")))
        mid.addView(numRow(ndig("7"), ndig("8"), ndig("9")))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp((keyH + 10) * 3))
        top.addView(vcol(cs, vcell(nsym("+", cs, "@")), vcell(nsym("-", cs, "#")), vcell(nsym("*", cs)), vcell(nsym("/", cs))))
        top.addView(mid)
        top.addView(vcol(cs, vcell(nsym("%", cs, "$")), vcell(sp), vcell(bk)))
        r.addView(top)

        val abc = key("ABC", cs, true, 15f, { flush(); mode = "sym"; build() }) { flush(); mode = layoutFor(lang); build() }
        abc.background = GradientDrawable().also { it.setColor(th.keyAlt); it.cornerRadius = dp(40).toFloat() }
        r.addView(numRow(
            abc,
            nsym(",", 0.5f), nsym("?", 0.5f),
            ndig("0"),
            nsym("=", 0.5f), nsym(".", 0.5f),
            ok
        ))
    }

    // ---------- panels ----------
    private fun panelView(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val head = rowOf(
            key("ABC", 1.3f, true, 15f) { panel = ""; build() },
            ik("emoji", 1f, panel == "emoji") { panel = "emoji"; build() },
            ik("sticker", 1f, panel == "sticker") { panel = "sticker"; build() },
            ik("clip", 1f, panel == "clip") { panel = "clip"; build() },
            backKey(1.3f)
        )
        head.layoutParams.height = dp(46)
        c.addView(head)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyH * 4))
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body)
        when (panel) {
            "emoji" -> emojiGrid(body, Words.emoji, 8, 26f, 44)
            "sticker" -> {
                emojiGrid(body, Words.stickers, 5, 36f, 64)
                for (chunk in Words.textStickers.chunked(2)) {
                    val row = LinearLayout(this)
                    row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
                    for (s in chunk) {
                        val t = TextView(this)
                        t.text = s; t.gravity = Gravity.CENTER; t.textSize = 15f; t.setTextColor(th.text)
                        t.background = keyBg(th.key)
                        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3)); t.layoutParams = lp
                        t.setOnClickListener { buzz(); commit(s) }
                        row.addView(t)
                    }
                    body.addView(row)
                }
            }
            else -> {
                val clips = getList("clips")
                if (clips.isEmpty()) {
                    val t = TextView(this)
                    t.text = "ক্লিপবোর্ড খালি — কিছু কপি করুন"
                    t.setTextColor(th.dim); t.gravity = Gravity.CENTER; t.setPadding(0, dp(30), 0, 0)
                    body.addView(t)
                }
                for (s in clips) {
                    val t = TextView(this)
                    t.text = s; t.maxLines = 2; t.ellipsize = TextUtils.TruncateAt.END
                    t.setTextColor(th.text); t.textSize = 15f; t.setPadding(dp(12), dp(10), dp(12), dp(10))
                    t.background = keyBg(th.key)
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3)); t.layoutParams = lp
                    t.setOnClickListener { buzz(); commit(s) }
                    body.addView(t)
                }
            }
        }
        c.addView(sv)
        return c
    }

    private fun emojiGrid(body: LinearLayout, items: List<String>, cols: Int, size: Float, hDp: Int) {
        for (chunk in items.chunked(cols)) {
            val row = LinearLayout(this)
            row.weightSum = cols.toFloat()
            row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(hDp))
            for (e in chunk) {
                val t = TextView(this)
                t.text = e; t.textSize = size; t.gravity = Gravity.CENTER
                t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                t.setOnClickListener { buzz(); commit(e) }
                row.addView(t)
            }
            body.addView(row)
        }
    }

    // ---------- input actions ----------
    private fun flush() {
        if (comp.isEmpty()) return
        val w = Phonetic.convert(comp.toString())
        currentInputConnection?.commitText(w, 1)
        addRecent(w)
        comp.setLength(0)
    }

    private fun commit(s: String) {
        voiceOff()
        flush()
        if (s.none { isWordChar(it) }) lastFin = null
        currentInputConnection?.commitText(s, 1)
        lastBase = null
        refreshKar(); updateSuggestions()
    }

    private fun phon(ch: String) {
        voiceOff()
        comp.append(ch)
        currentInputConnection?.setComposingText(Phonetic.convert(comp.toString()), 1)
        updateSuggestions()
    }

    private fun doBackspace() {
        voiceOff()
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) {
            comp.deleteCharAt(comp.length - 1)
            if (comp.isEmpty()) ic.commitText("", 1)
            else ic.setComposingText(Phonetic.convert(comp.toString()), 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun onSpace() {
        voiceOff()
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) flush() else autoFixAndRemember()
        ic.commitText(" ", 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun autoFixAndRemember() {
        val ic = currentInputConnection ?: return
        val w = curWord()
        if (w.length < 2) return
        var out = w
        if (mode == "en" && !noLearn && prefs.getBoolean("autocorrect", true) && w.length >= 3 &&
            w.all { it in 'a'..'z' || it in 'A'..'Z' } && !Words.enSet.contains(w.lowercase())
        ) {
            val fix = Words.fix(w.lowercase())?.takeIf { !w.lowercase().startsWith(it) }
            if (fix != null) {
                out = if (w[0].isUpperCase()) fix.replaceFirstChar { it.uppercaseChar() } else fix
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(out, 1)
            }
        }
        addRecent(out)
    }

    private fun enterKey() {
        voiceOff()
        flush()
        lastFin = null
        if (!sendDefaultEditorAction(true)) currentInputConnection?.commitText("\n", 1)
        lastBase = null; refreshKar(); updateSuggestions()
    }

    private fun switchLang() {
        flush()
        lang = if (lang == "bn") "en" else "bn"
        prefs.edit().putString("lang", lang).apply()
        mode = layoutFor(lang); panel = ""; shift = false; caps = false
        build()
    }

    private fun toggleBnLayout() {
        flush()
        val cur = prefs.getString("bnlayout", "classic")
        prefs.edit().putString("bnlayout", if (cur == "phonetic") "classic" else "phonetic").apply()
        lang = "bn"; prefs.edit().putString("lang", "bn").apply()
        mode = layoutFor("bn"); tools = false
        build()
    }

    private fun imePicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }


    // ---------- personal dictionary (learns every word you type or speak) ----------
    @Volatile private var ud: java.util.TreeMap<String, Int>? = null
    private var udDirty = false
    private val udPending = HashMap<String, Int>()   // voice words seen once; kept only after a 2nd time
    private val udSave = Runnable { saveUd() }
    private fun udFile() = java.io.File(filesDir, "udict.txt")

    private fun loadUd() {
        Thread {
            val m = java.util.TreeMap<String, Int>()
            try {
                val f = udFile()
                if (f.exists()) f.bufferedReader().useLines { ls ->
                    for (ln in ls) {
                        val i = ln.lastIndexOf('\t')
                        if (i <= 0) continue
                        val c = ln.substring(i + 1).toIntOrNull() ?: continue
                        m[ln.substring(0, i)] = c
                    }
                }
            } catch (e: Exception) { }
            ud = m
        }.start()
    }

    private fun saveUd() {
        val m = ud ?: return
        udDirty = false
        val sb = StringBuilder()
        for ((w, c) in m) sb.append(w).append('\t').append(c).append('\n')
        val txt = sb.toString()
        Thread {
            try {
                val f = udFile(); val t = java.io.File(filesDir, "udict.tmp")
                t.writeText(txt)
                if (!t.renameTo(f)) { f.writeText(txt); t.delete() }
            } catch (e: Exception) { }
        }.start()
    }

    private fun learnWord(w0: String, voice: Boolean) {
        if (noLearn || !prefs.getBoolean("udict", true) || isBlocked(w0)) return
        val m = ud ?: return
        if (w0.length < 2 || w0.length > 24) return
        if (!w0.all { isWordChar(it) && !it.isDigit() }) return
        val w = w0.lowercase()
        val cur = m[w]
        if (cur != null) m[w] = cur + 1
        else if (voice) {
            val p = (udPending[w] ?: 0) + 1
            if (p >= 2) { udPending.remove(w); m[w] = 2 }
            else { udPending[w] = p; if (udPending.size > 500) udPending.clear(); return }
        } else m[w] = 1
        if (m.size > 50000) {
            val it = m.entries.iterator()
            while (it.hasNext() && m.size > 40000) { if (it.next().value <= 1) it.remove() }
        }
        udDirty = true
        h.removeCallbacks(udSave); h.postDelayed(udSave, 8000)
    }

    /** learned words starting with w, most used first */
    private fun userMatches(w: String): List<String> {
        val m = ud ?: return emptyList()
        val k = w.lowercase()
        val best = ArrayList<Map.Entry<String, Int>>()
        try {
            var n = 0
            for (e in m.subMap(k, k + '\uffff').entries) { if (++n > 400) break; best.add(e) }
        } catch (e: Exception) { return emptyList() }
        best.sortByDescending { it.value }
        return best.map { it.key }
    }

    // ---------- next-word prediction (learns which word follows which) ----------
    @Volatile private var bi: HashMap<String, LinkedHashMap<String, Int>>? = null
    private var biDirty = false
    private var lastFin: String? = null     // previous finished word (reset on punctuation / enter / new field)
    private val biSave = Runnable { saveBi() }
    private val prevRe = Regex("([\\p{L}\\p{M}']+)\\s$")
    private fun biFile() = java.io.File(filesDir, "bigram.txt")

    private fun nextOn() = prefs.getBoolean("nextword", true)

    private fun loadBi() {
        Thread {
            val m = HashMap<String, LinkedHashMap<String, Int>>()
            try {
                val f = biFile()
                if (f.exists()) f.bufferedReader().useLines { ls ->
                    for (ln in ls) {
                        val p = ln.split('\t')
                        if (p.size != 3) continue
                        val c = p[2].toIntOrNull() ?: continue
                        m.getOrPut(p[0]) { LinkedHashMap() }[p[1]] = c
                    }
                }
            } catch (e: Exception) { }
            bi = m
        }.start()
    }

    private fun saveBi() {
        val m = bi ?: return
        biDirty = false
        var list = ArrayList<Triple<String, String, Int>>()
        for ((a, mm) in m) for ((b, c) in mm) list.add(Triple(a, b, c))
        if (list.size > 3000) {
            list.sortByDescending { it.third }
            list = ArrayList(list.subList(0, 2500))
            m.clear()
            for ((a, b, c) in list) m.getOrPut(a) { LinkedHashMap() }[b] = c
        }
        val sb = StringBuilder()
        for ((a, b, c) in list) sb.append(a).append('\t').append(b).append('\t').append(c).append('\n')
        val txt = sb.toString()
        Thread {
            try {
                val f = biFile(); val t = java.io.File(filesDir, "bigram.tmp")
                t.writeText(txt)
                if (!t.renameTo(f)) { f.writeText(txt); t.delete() }
            } catch (e: Exception) { }
        }.start()
    }

    /** called with every finished word: remembers (previous word -> this word). No calls into the editor app. */
    private fun learnBigram(w0: String) {
        if (noLearn || !nextOn()) { lastFin = null; return }
        val c = if (w0 == "I") w0 else w0.lowercase()
        if (c.isEmpty() || (c.length < 2 && c != "I") || !c.all { isWordChar(it) } || isBlocked(c)) { lastFin = null; return }
        val a = lastFin
        lastFin = c
        if (a == null || isBlocked(a)) return
        val m = bi ?: return
        val mm = m.getOrPut(a) { LinkedHashMap() }
        mm[c] = (mm[c] ?: 0) + 1
        if (mm.size > 8) {
            val low = mm.entries.minByOrNull { it.value }?.key
            if (low != null && low != c) mm.remove(low)
        }
        biDirty = true
        h.removeCallbacks(biSave); h.postDelayed(biSave, 8000)
    }

    /** words that usually come after the word just finished; [b] = text before the cursor (already fetched) */
    private fun nextWords(b: String): List<String> {
        if (!nextOn()) return emptyList()
        val m = prevRe.find(b) ?: return emptyList()
        val a = m.groupValues[1].lowercase()
        val out = ArrayList<String>(SUG_N)
        val learned = bi?.get(a)
        if (learned != null) {
            for (e in learned.entries.sortedByDescending { it.value }) { if (out.size >= SUG_N) break; out.add(e.key) }
        }
        Words.seed[a]?.let { for (x in it) if (out.size < SUG_N && !out.contains(x)) out.add(x) }
        return out
    }

    // ---------- suggestions ----------
    private fun isWordChar(c: Char): Boolean {
        if (Character.isLetterOrDigit(c) || c == '\u09CD') return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun curWord(): String {
        if (comp.isNotEmpty()) return Phonetic.convert(comp.toString())
        val b = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString() ?: return ""
        var i = b.length
        while (i > 0 && isWordChar(b[i - 1])) i--
        return b.substring(i)
    }

    private fun suggest(): List<String> {
        val l = suggestRaw()
        if (l.isEmpty() || prefs.getString("blockwords", "").isNullOrEmpty()) return l
        // keep the word being typed (index 0 while composing); drop blocked completions
        return l.filterIndexed { i, x -> (i == 0 && comp.isNotEmpty()) || !isBlocked(x) }
    }

    private fun suggestRaw(): List<String> {
        // ONE call into the editor app per update (each call can take 10-100 ms in heavy apps)
        val before = if (comp.isEmpty()) (currentInputConnection?.getTextBeforeCursor(40, 0)?.toString() ?: "") else ""
        val w = if (comp.isNotEmpty()) Phonetic.convert(comp.toString()) else {
            val t = before.takeLast(24); var k = t.length
            while (k > 0 && isWordChar(t[k - 1])) k--
            t.substring(k)
        }
        val rec = recent()
        if (w.isEmpty()) {
            val nx = nextWords(before)
            val base = if (lang == "bn") listOf("আমি", "আপনি", "ধন্যবাদ", "আমার", "আপনার", "এই", "কী", "না")
                       else listOf("I", "The", "Hello", "Thanks", "How", "What", "Yes", "No")
            return (nx + rec.take(SUG_N) + base).distinct().take(SUG_N)
        }
        val out = ArrayList<String>(SUG_N)
        out.add(w)
        fun scan(src: List<String>) {
            for (x in src) {
                if (out.size >= SUG_N) return
                if (x.startsWith(w, ignoreCase = true) && !x.equals(w, ignoreCase = true) && !out.contains(x)) out.add(x)
            }
        }
        val isBn = w[0].code >= 0x0980
        scan(rec)
        scan(userMatches(w))
        scan(if (isBn) Words.bn else Words.en)
        // phonetic loose match: "ami" -> আমি also offers আমার, আমরা (compare words with vowel signs removed)
        if (isBn && comp.isNotEmpty() && out.size < SUG_N) {
            val k = skel(w)
            if (skelSrc !== Words.bn) { skelSrc = Words.bn; skelList = Words.bn.map { skel(it) } }
            val loose = ArrayList<String>()
            for (x in rec) if (skel(x).startsWith(k)) loose.add(x)
            for (i in Words.bn.indices) if (skelList[i].startsWith(k)) loose.add(Words.bn[i])
            for (x in loose.distinct().sortedBy { it.length }) {   // shorter (more common) words first
                if (out.size >= SUG_N) break
                if (!out.contains(x)) out.add(x)
            }
        }
        return out
    }

    private val karRe = Regex("[\u09BE-\u09CC]")
    private var skelSrc: List<String>? = null
    private var skelList: List<String> = emptyList()
    private fun skel(x: String) = x.replace(karRe, "")

    /** Coalesced: many calls during one key press -> one cheap update right after the key has been handled. */
    private fun updateSuggestions() {
        if (sug.size < SUG_N || sugPending) return
        sugPending = true
        h.postDelayed(sugRun, 90)
    }

    private fun doUpdateSuggestions() {
        if (sug.size < SUG_N) return
        val l = if (!noLearn && prefs.getBoolean("sugg", true)) suggest() else emptyList()
        var changed = false
        for (i in 0 until SUG_N) {
            val s = l.getOrElse(i) { "" }
            if (sug[i].text.toString() != s) { sug[i].text = s; changed = true }
            sug[i].visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
        }
        if (changed) sugScroll?.scrollTo(0, 0)
    }

    private fun pickSuggestion(s: String) {
        if (s.isEmpty()) return
        voiceOff()
        val ic = currentInputConnection ?: return
        if (comp.isNotEmpty()) {
            comp.setLength(0)
        } else {
            val w = curWord()
            if (w.isNotEmpty()) ic.deleteSurroundingText(w.length, 0)
        }
        ic.commitText("$s ", 1)
        addRecent(s)
        lastBase = null; refreshKar(); updateSuggestions()
    }
}
