package com.banglakeys.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private var tab = 0
    private var inSub = false
    private var chip = 0
    private val checks = ArrayList<Pair<String, View>>()

    private val BG = 0xFF1F2025.toInt()
    private val NAVBG = 0xFF35363C.toInt()
    private val CARD = 0xFF37383D.toInt()
    private val TXT = 0xFFE3E3E8.toInt()
    private val DIM = 0xFF9A9BA3.toInt()
    private val BLUE = 0xFF5280F0.toInt()
    private val HEAD = 0xFF5B84F5.toInt()
    private val CHIP = 0xFF46474D.toInt()
    private val M = -1
    private val W = -2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int): GradientDrawable {
        val g = GradientDrawable(); g.setColor(c); g.cornerRadius = dp(r).toFloat(); return g
    }
    private fun tv(t: String, size: Float, color: Int = TXT, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }

    // ---------- app (settings) language: only changes this screen, not the keyboard ----------
    private fun uiEn() = (p.getString("uilang", "bn") ?: "bn") == "en"

    private val EN = linkedMapOf(
        "ক্লিপবোর্ড হিস্ট্রি মুছুন" to "Clear clipboard history",
        "ক্লিপবোর্ড হিস্ট্রি চালু" to "Clipboard history on",
        "ক্লিপবোর্ড হিস্ট্রি" to "Clipboard history",
        "ফ্ল্যাট কি (ব্যাকগ্রাউন্ড ছাড়া)" to "Flat keys (no background)",
        "কি-এর উপরে সংখ্যা/চিহ্ন হিন্ট" to "Number/symbol hints on keys",
        "এন্টার কি রঙিন (অ্যাকসেন্ট)" to "Colored Enter key (accent)",
        "এন্টার কি রঙিন" to "Colored Enter key",
        "সাজেশন বার চালু" to "Suggestion bar on",
        "সাজেশন বার দেখান" to "Show suggestion bar",
        "কি-হাইট (dp)" to "Key height (dp)",
        "কি গ্যাপ (dp)" to "Key gap (dp)",
        "ফন্ট সাইজ (%)" to "Font size (%)",
        "ইংরেজি অটো-কারেক্ট" to "English auto-correct",
        "Import শীঘ্রই আসছে" to "Import coming soon",
        "ব্যাকগ্রাউন্ড #RRGGBB" to "Background #RRGGBB",
        "কি রঙ #RRGGBB" to "Key color #RRGGBB",
        "অ্যাকসেন্ট #RRGGBB" to "Accent #RRGGBB",
        "রঙের কোড ঠিক নেই (যেমন #1A1A20)" to "Invalid color code (e.g. #1A1A20)",
        "কি চাপলে ভাইব্রেশন" to "Vibrate on key press",
        "ফ্ল্যাট কি" to "Flat keys",
        "কি হিন্ট (সংখ্যা/চিহ্ন)" to "Key hints (numbers/symbols)",
        "কাস্টম ফন্ট ইনস্টল সুবিধা এখনো নেই।" to "Custom font install is not available yet.",
        "অ্যাপের ভাষা (শুধু এই সেটিংস অ্যাপের লেখা বদলাবে, কিবোর্ড নয়)" to "App language (changes only the text in this settings app, not the keyboard)",
        "বাংলা লেআউট" to "Bangla layout",
        "ক্লাসিক (গ্রিড)" to "Classic (grid)",
        "ফোনেটিক (অভ্র/প্রবাত স্টাইল)" to "Phonetic (Avro/Probhat style)",
        "শেখা (রিসেন্ট) শব্দ:" to "Learned (recent) words:",
        "বিল্ট-ইন ডিকশনারি:" to "Built-in dictionary:",
        "assets/bn_words.txt ও en_words.txt ফাইলে শব্দ যোগ করা যায়।" to "you can add words in assets/bn_words.txt and en_words.txt.",
        "শেখা শব্দ মুছুন" to "Clear learned words",
        "সংরক্ষিত ক্লিপ:" to "Saved clips:",
        "মুছে ফেলা হয়েছে" to "Cleared",
        "স্বরবর্ণ:" to "Vowels:",
        "ব্যঞ্জন পরপর লিখলে হসন্ত যুক্ত হয়" to "consecutive consonants join with hasanta",
        "ব্যঞ্জন:" to "Consonants:",
        "যুক্তাক্ষর:" to "Conjuncts:",
        "ফলা/রেফ:" to "Phala/Reph:",
        "দীর্ঘ স্বর:" to "Long vowels:",
        "উদাহরণ:" to "Example:",
        "সব সেটিংস রিসেট করুন" to "Reset all settings",
        "রিসেট হয়েছে" to "Reset done",
        "শীঘ্রই আসছে" to "Coming soon",
        "এখনো তৈরি হয়নি" to "Not built yet",
        "কিবোর্ড চালু করুন" to "Enable keyboard",
        "সিস্টেম সেটিংসে অন করুন" to "Turn on in system settings",
        "এই কিবোর্ড বেছে নিন" to "Select this keyboard",
        "ইনপুট মেথড বদলান" to "Change input method",
        "টেস্ট করুন" to "Test",
        "এখানে টাইপ করে দেখুন" to "Type here to try",
        "আপডেট চেক করুন" to "Check for update",
        "কি প্রেস সাউন্ড" to "Key press sound",
        "কি চাপলে শব্দ হবে" to "Play a sound when you tap a key",
        "সাউন্ড চালু" to "Sound on",
        "শব্দের ভলিউম" to "Sound volume",
        "বর্তমান ভার্সন" to "Current version",
        "চেক করা হচ্ছে…" to "Checking…",
        "নতুন আপডেট এসেছে" to "New update available",
        "নতুন ভার্সন" to "New version",
        "ডাউনলোড করুন" to "Download",
        "পরে" to "Later",
        "আপনার ভার্সন সর্বশেষ" to "You have the latest version",
        "আপডেট চেক করা যায়নি। ইন্টারনেট দেখুন।" to "Could not check for updates. Check your internet.",
        "এই APK GitHub Actions দিয়ে বানানো হয়নি, তাই রিপোজিটরির নাম জানা নেই।" to "This APK was not built by GitHub Actions, so the repository name is unknown.",
        "GitHub-এ কোনো Release পাওয়া যায়নি। রিপোজিটরি পাবলিক কিনা আর Release তৈরি হয়েছে কিনা দেখুন।" to "No Release found on GitHub. Check that the repository is public and a Release was created.",
        "GitHub সাময়িকভাবে অনেক রিকোয়েস্ট আটকে দিয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।" to "GitHub is temporarily limiting requests. Try again in a while."
    )
    private val ENS by lazy { EN.entries.sortedByDescending { it.key.length } }

    private fun T(s: String): String {
        if (!uiEn()) return s
        var r = s
        for (e in ENS) if (r.contains(e.key)) r = r.replace(e.key, e.value)
        return r
    }

    private fun toast(s: String) = Toast.makeText(this, T(s), Toast.LENGTH_SHORT).show()

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val x = LinearLayout.LayoutParams(w, h); x.setMargins(dp(l), dp(t), dp(r), dp(b)); return x
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("kb", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = NAVBG
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(M, 0, 1f))
        nav = LinearLayout(this)
        nav.setBackgroundColor(NAVBG)
        nav.setPadding(0, dp(10), 0, dp(10))
        root.addView(nav, LinearLayout.LayoutParams(M, W))
        setContentView(root)
        show(0)
        // auto update check (at most once every 6 hours)
        val now = System.currentTimeMillis()
        if (now - p.getLong("upd_last", 0L) > 6 * 3600 * 1000L) {
            p.edit().putLong("upd_last", now).apply()
            checkUpdate(false)
        }
    }

    private fun checkUpdate(manual: Boolean) {
        UpdateChecker.check { r ->
            if (isFinishing || isDestroyed) return@check
            when {
                r.error != null -> if (manual) {
                    val m = when (r.error) {
                        "norepo" -> "এই APK GitHub Actions দিয়ে বানানো হয়নি, তাই রিপোজিটরির নাম জানা নেই।"
                        "http404" -> "GitHub-এ কোনো Release পাওয়া যায়নি। রিপোজিটরি পাবলিক কিনা আর Release তৈরি হয়েছে কিনা দেখুন।"
                        "http403" -> "GitHub সাময়িকভাবে অনেক রিকোয়েস্ট আটকে দিয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                        "net" -> "আপডেট চেক করা যায়নি। ইন্টারনেট দেখুন।"
                        else -> "আপডেট চেক করা যায়নি। (" + r.error + ")"
                    }
                    AlertDialog.Builder(this).setMessage(T(m)).setPositiveButton("OK", null).show()
                }
                r.newer -> {
                    val msg = T("নতুন ভার্সন") + ": " + r.tag + (if (r.notes.isNotBlank()) "\n\n" + r.notes.trim().take(400) else "")
                    AlertDialog.Builder(this)
                        .setTitle(T("নতুন আপডেট এসেছে"))
                        .setMessage(msg)
                        .setPositiveButton(T("ডাউনলোড করুন")) { _, _ ->
                            try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(r.url))) } catch (e: Exception) {}
                        }
                        .setNegativeButton(T("পরে"), null)
                        .show()
                }
                else -> if (manual) toast("আপনার ভার্সন সর্বশেষ")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (inSub) show(tab) else super.onBackPressed() }

    // ---------- navigation ----------
    private fun show(t: Int) {
        tab = t; inSub = false
        content.removeAllViews()
        checks.clear()
        val pg = when (t) { 0 -> homePage(); 1 -> themesPage(); else -> settingsPage() }
        content.addView(scroll(pg))
        nav.removeAllViews()
        val icons = listOf("kbd", "palette", "gear")
        for (i in 0..2) {
            val item = LinearLayout(this)
            item.gravity = Gravity.CENTER
            val ic = IconView(this, icons[i], if (i == t) Color.WHITE else DIM)
            if (i == t) ic.background = bg(BLUE, 24)
            item.addView(ic, LinearLayout.LayoutParams(dp(84), dp(40)))
            item.setOnClickListener { show(i) }
            nav.addView(item, LinearLayout.LayoutParams(0, W, 1f))
        }
    }

    private fun scroll(v: View): ScrollView { val s = ScrollView(this); s.addView(v); return s }

    private fun page(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(14), dp(24), dp(14), dp(24))
        return l
    }

    private fun openSub(title: String, action: (() -> Unit)? = null, f: (LinearLayout) -> Unit) {
        inSub = true
        content.removeAllViews()
        val pg = page()
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(0, 0, 0, dp(20))
        // back arrow with a light grey rounded background
        val back = tv("←", 22f, TXT, true)
        back.gravity = Gravity.CENTER
        back.background = bg(0xFF3F4046.toInt(), 14)
        back.setOnClickListener { show(tab) }
        bar.addView(back, lp(dp(46), dp(46)))
        val ttl = tv(T(title), 20f, TXT, true)
        ttl.setPadding(dp(14), 0, 0, 0)
        bar.addView(ttl, lp(0, W).also { it.weight = 1f })
        if (action != null) {
            val plus = tv("+", 28f, Color.WHITE, true)
            plus.gravity = Gravity.CENTER
            plus.background = bg(BLUE, 23)
            plus.setOnClickListener { action() }
            bar.addView(plus, lp(dp(46), dp(46)))
        }
        pg.addView(bar)
        f(pg)
        content.addView(scroll(pg))
    }

    // ---------- block words (never suggested, never saved) ----------
    private fun blockList(): MutableList<String> =
        (p.getString("blockwords", "") ?: "").split("\u0001").filter { it.isNotEmpty() }.toMutableList()

    private fun saveBlockList(l: List<String>) { p.edit().putString("blockwords", l.joinToString("\u0001")).apply() }

    private fun blockWordsPage() {
        openSub("Block words", { addBlockWordDialog() }) { c ->
            val note = tv(T("এই শব্দগুলো কখনো সাজেশনে আসবে না এবং কখনো সেভ/লার্ন হবে না।"), 13f, DIM)
            note.setPadding(dp(6), 0, dp(6), dp(14))
            c.addView(note)
            val l = blockList()
            if (l.isEmpty()) {
                val e = tv(T("কোনো শব্দ ব্লক করা নেই। ডান পাশের + চাপুন।"), 15f, DIM)
                e.setPadding(dp(6), dp(10), dp(6), 0)
                c.addView(e)
            }
            for (w in l) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(20), dp(14), dp(8), dp(14))
                r.background = bg(CARD, 14)
                r.addView(tv(w, 18f), lp(0, W).also { it.weight = 1f })
                val x = tv("✕", 18f, 0xFFEF6A6A.toInt(), true)
                x.setPadding(dp(16), dp(8), dp(16), dp(8))
                x.setOnClickListener { val n = blockList(); n.remove(w); saveBlockList(n); blockWordsPage() }
                r.addView(x)
                c.addView(r, lp(M, W, 0, 0, 0, 6))
            }
        }
    }

    private fun addBlockWordDialog() {
        val et = EditText(this)
        et.setSingleLine(true); et.setTextColor(TXT); et.setHintTextColor(DIM)
        et.hint = T("বাংলা বা ইংরেজি শব্দ লিখুন")
        val box = FrameLayout(this); box.setPadding(dp(24), dp(8), dp(24), 0); box.addView(et)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Add blocked word")
            .setView(box)
            .setPositiveButton("ADD") { _, _ ->
                val w = et.text.toString().trim().lowercase()
                if (w.isNotEmpty()) {
                    val l = blockList()
                    if (!l.contains(w)) { l.add(0, w); saveBlockList(l) }
                    blockWordsPage()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
        et.requestFocus()
    }

    // ---------- reusable widgets ----------
    // ---------- small modern icons on every option row ----------
    private val OI: Map<String, Pair<String, Int>> = mapOf(
        "vibrate" to ("vibrate" to 0xFF8B5CF6.toInt()), "vib_str" to ("vibwave" to 0xFFA855F7.toInt()),
        "keysound" to ("sound" to 0xFFF59E0B.toInt()), "snd_vol" to ("volume" to 0xFFF97316.toInt()),
        "keypopup" to ("popup" to 0xFF06B6D4.toInt()),
        "kh_p" to ("height" to 0xFF3B82F6.toInt()), "kh_l" to ("height" to 0xFF0EA5E9.toInt()),
        "pad_p" to ("padding" to 0xFF14B8A6.toInt()), "pad_l" to ("padding" to 0xFF10B981.toInt()),
        "keyh" to ("height" to 0xFF3B82F6.toInt()), "gap" to ("gap" to 0xFF22C55E.toInt()), "fscale" to ("font" to 0xFF9B5CF6.toInt()),
        "sugg" to ("suggest" to 0xFFEC4899.toInt()), "autocorrect" to ("check" to 0xFF10B981.toInt()),
        "mixvoice" to ("mic" to 0xFFEF4444.toInt()), "nextword" to ("next" to 0xFF6366F1.toInt()),
        "udict" to ("book" to 0xFFF59E0B.toInt()), "flat" to ("flat" to 0xFF64748B.toInt()),
        "hints" to ("hash" to 0xFF0EA5E9.toInt()), "enteraccent" to ("enter" to 0xFF22C55E.toInt()),
        "clipon" to ("clip" to 0xFF3B82F6.toInt()), "uilang" to ("globe" to 0xFF14B8A6.toInt()),
        "bnlayout" to ("kbd" to 0xFF3B82F6.toInt())
    )

    private fun oi(key: String, glyph: String? = null, color: Int? = null): View {
        val e = OI[key]
        val v = TileIcon(this, glyph ?: e?.first ?: "more", color ?: e?.second ?: 0xFF6366F1.toInt(), null)
        v.layoutParams = lp(dp(34), dp(34), 0, 0, 14, 0)
        return v
    }

    private fun orow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(14), dp(16), dp(14))
        r.background = bg(CARD, 16)
        return r
    }

    private fun header(c: LinearLayout, t: String) {
        val h = tv(T(t), 16f, HEAD, true)
        h.setPadding(dp(10), dp(28), 0, dp(14))
        c.addView(h)
    }

    private fun item(c: LinearLayout, icon: String, iconBg: Int, title: String, desc: String? = null, f: () -> Unit) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(20), dp(18), dp(16), dp(18))
        r.background = bg(CARD, 18)
        val parts = icon.split("|")
        val ic = TileIcon(this, parts[0], iconBg, parts.getOrNull(1))
        r.addView(ic, lp(dp(48), dp(48)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(T(title), 18f))
        if (desc != null) col.addView(tv(T(desc), 13f, DIM))
        r.addView(col, lp(0, W, 20, 0, 0, 0).also { it.weight = 1f })
        r.setOnClickListener { f() }
        c.addView(r, lp(M, W, 0, 0, 0, 4))
    }

    private fun plain(c: LinearLayout, title: String, f: () -> Unit) {
        val r = orow()
        r.setPadding(dp(16), dp(20), dp(16), dp(20))
        val g = when { title.contains("Gap") -> "gap"; title.contains("Suggestion") -> "suggest"; else -> "more" }
        val col = when (g) { "gap" -> 0xFF22C55E.toInt(); "suggest" -> 0xFFEC4899.toInt(); else -> 0xFF6366F1.toInt() }
        r.addView(oi("", g, col))
        r.addView(tv(T(title), 18f), LinearLayout.LayoutParams(0, W, 1f))
        r.setOnClickListener { f() }
        c.addView(r, lp(M, W, 0, 0, 0, 6))
    }

    private fun sw(c: LinearLayout, key: String, text: String, def: Boolean, after: (() -> Unit)? = null) {
        val row = orow()
        row.setPadding(dp(16), 0, dp(18), 0)
        row.addView(oi(key))
        val s = Switch(this)
        s.text = T(text); s.setTextColor(TXT); s.textSize = 16f
        s.isChecked = p.getBoolean(key, def)
        s.setPadding(0, dp(16), 0, dp(16))
        s.setOnCheckedChangeListener { _, ch -> p.edit().putBoolean(key, ch).apply(); after?.invoke() }
        row.addView(s, LinearLayout.LayoutParams(0, W, 1f))
        c.addView(row, lp(M, W, 0, 0, 0, 4))
    }
    private fun radios(c: LinearLayout, key: String, def: String, opts: List<Pair<String, String>>, after: (() -> Unit)? = null) {
        val g = RadioGroup(this)
        g.setPadding(0, dp(4), 0, dp(4))
        for (o in opts) {
            val r = RadioButton(this)
            r.text = T(o.second); r.setTextColor(TXT); r.textSize = 16f
            r.id = View.generateViewId(); r.tag = o.first
            r.isChecked = (p.getString(key, def) ?: def) == o.first
            g.addView(r)
        }
        g.setOnCheckedChangeListener { grp, id ->
            val v = grp.findViewById<View>(id)
            if (v != null) { p.edit().putString(key, v.tag as String).apply(); after?.invoke() }
        }
        c.addView(g, lp(M, W, 0, 0, 0, 4))
    }

    private fun seek(c: LinearLayout, key: String, min: Int, max: Int, def: Int, title: String, unit: String = "") {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val cur = p.getInt(key, def)
        val ttl = T(title)
        val lab = tv("$ttl: $cur$unit", 16f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                lab.text = "$ttl: ${v + min}$unit"
                p.edit().putInt(key, v + min).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(lab); box.addView(sb)
        val row = orow()
        row.addView(oi(key))
        row.addView(box, LinearLayout.LayoutParams(0, W, 1f))
        c.addView(row, lp(M, W, 0, 0, 0, 4))
    }

    /** switch row with a title and a small description (like the Key tap screen) */
    private fun swd(c: LinearLayout, key: String, title: String, desc: String?, def: Boolean, after: (() -> Unit)? = null) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(18), dp(16), dp(18), dp(16))
        row.background = bg(CARD, 16)
        row.addView(oi(key))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(T(title), 17f))
        if (desc != null) col.addView(tv(T(desc), 13f, DIM))
        row.addView(col, LinearLayout.LayoutParams(0, W, 1f))
        val s = Switch(this)
        s.isChecked = p.getBoolean(key, def)
        s.setOnCheckedChangeListener { _, ch -> p.edit().putBoolean(key, ch).apply(); after?.invoke() }
        row.addView(s)
        row.setOnClickListener { s.toggle() }
        c.addView(row, lp(M, W, 0, 0, 0, 4))
    }

    /** card that shows the current value and opens a single-choice dialog */
    private fun choice(c: LinearLayout, key: String, title: String, def: String, opts: List<Pair<String, String>>, enabled: Boolean = true, after: (() -> Unit)? = null) {
        val cur = p.getString(key, def) ?: def
        val row = orow()
        row.addView(oi(key))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(T(title), 17f))
        col.addView(tv(T(opts.firstOrNull { it.first == cur }?.second ?: opts[0].second), 13f, DIM))
        row.addView(col, LinearLayout.LayoutParams(0, W, 1f))
        if (!enabled) row.alpha = 0.4f
        else row.setOnClickListener {
            val names = opts.map { T(it.second) }.toTypedArray()
            AlertDialog.Builder(this).setTitle(T(title))
                .setSingleChoiceItems(names, opts.indexOfFirst { it.first == cur }.coerceAtLeast(0)) { d, i ->
                    p.edit().putString(key, opts[i].first).apply(); d.dismiss(); (after ?: { keyTapPage() })()
                }.setNegativeButton("Cancel", null).show()
        }
        c.addView(row, lp(M, W, 0, 0, 0, 4))
    }

    private fun keySoundPage() {
        openSub("কি প্রেস সাউন্ড") { c ->
            val snd = p.getBoolean("keysound", false)
            swd(c, "keysound", "সাউন্ড চালু", "কি চাপলে শব্দ হবে", false) { keySoundPage() }
            choice(c, "snd_vol", "শব্দের ভলিউম", "sys", listOf("sys" to "System default", "25" to "25%", "50" to "50%", "75" to "75%", "100" to "100%"), snd) { keySoundPage() }
        }
    }

    private fun keyTapPage() {
        openSub("Key tap") { c ->
            val vib = p.getBoolean("vibrate", true)
            swd(c, "vibrate", "Keyboard vibration", null, true) { keyTapPage() }
            choice(c, "vib_str", "Vibration strength on keypress", "sys", listOf("sys" to "System default", "light" to "Light", "medium" to "Medium", "strong" to "Strong"), vib)
            swd(c, "keypopup", "Key pop-up", "Show indicator to see which key you're pressing", true)
        }
    }

    private fun keySizePage() {
        openSub("Keyboard size") { c ->
            seek(c, "kh_p", 50, 150, 100, "Keyboard height (Portrait)", "%")
            seek(c, "kh_l", 50, 150, 100, "Keyboard height (Landscape)", "%")
            seek(c, "pad_p", 0, 100, 0, "Keyboard bottom padding", "%")
            seek(c, "pad_l", 0, 100, 0, "Keyboard bottom padding (Landscape)", "%")
        }
    }

    private fun note(c: LinearLayout, t: String) {
        val v = tv(T(t), 15f, DIM)
        v.setPadding(dp(14), dp(10), dp(14), dp(10))
        c.addView(v)
    }

    private fun btn(c: LinearLayout, t: String, f: () -> Unit) {
        val row = orow()
        val reset = t.contains("রিসেট")
        row.addView(oi("", if (reset) "reset" else "trash", if (reset) 0xFFF97316.toInt() else 0xFFEF4444.toInt()))
        row.addView(tv(T(t), 17f), LinearLayout.LayoutParams(0, W, 1f))
        row.setOnClickListener { f() }
        c.addView(row, lp(M, W, 0, 0, 0, 4))
    }

    // ---------- default keyboard setup ----------
    private fun isEnabled(): Boolean {
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return im.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun isDefault(): Boolean {
        val d = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return d.startsWith("$packageName/")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::content.isInitialized && !inSub && tab == 0) show(0)
    }

    // ---------- Home (💡) ----------
    private fun homePage(): LinearLayout {
        val pg = page()
        val th = Themes.get(p.getString("theme", "dark") ?: "dark", p)
        val flat = p.getBoolean("flat", false)
        val hints = p.getBoolean("hints", true)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(14), dp(14), dp(14))
        card.background = bg(CARD, 28)

        val kb = LinearLayout(this)
        kb.orientation = LinearLayout.VERTICAL
        kb.setPadding(dp(6), dp(6), dp(6), dp(10))
        val g = th.grad
        if (g != null) {
            val gd = GradientDrawable(if (th.vert) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.TL_BR, g)
            gd.cornerRadius = dp(24).toFloat(); kb.background = gd
        } else kb.background = bg(th.bg, 24)

        val tb = LinearLayout(this)
        tb.gravity = Gravity.CENTER_VERTICAL
        for (k in listOf("lang", "emoji", "sticker", "num", "clip", "grid")) {
            tb.addView(IconView(this, k, th.text), LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        val mic = IconView(this, "mic", th.text)
        mic.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(th.keyAlt) }
        tb.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)))
        kb.addView(tb)

        fun prow(letters: String, hs: String, pad: Int, pre: String? = null, post: String? = null) {
            val r = LinearLayout(this)
            r.setPadding(dp(pad), 0, dp(pad), 0)
            fun side(s: String) {
                val v = IconView(this, if (s == "⇧") "shift" else "back", th.text)
                r.addView(v, LinearLayout.LayoutParams(0, dp(42), 1.4f))
            }
            if (pre != null) side(pre)
            for ((i, ch) in letters.withIndex()) {
                val t = HintTextView(this)
                t.text = ch.toString().uppercase(); t.textSize = 20f; t.setTextColor(th.text)
                t.gravity = Gravity.CENTER
                if (!flat) t.background = bg(th.key, 8)
                if (hints && i < hs.length) { t.hintText = hs[i].toString(); t.hintColor = th.dim; t.hintSize = dp(10).toFloat() }
                r.addView(t, lp(0, dp(42), 1, 2, 1, 2).also { it.weight = 1f })
            }
            if (post != null) side(post)
            kb.addView(r)
        }
        prow("qwertyuiop", "1234567890", 0)
        prow("asdfghjkl", "@#\$%&-+()", 14)
        prow("zxcvbnm", "*\"':;!?", 0, "⇧", "⌫")

        val bot = LinearLayout(this)
        bot.gravity = Gravity.CENTER_VERTICAL
        fun pill(s: String, w: Float, c: Int, tc: Int) {
            val t: View = if (s == "⏎") IconView(this, "enter", tc) else tv(s, 15f, tc).also { it.gravity = Gravity.CENTER }
            if (c != 0) t.background = bg(c, 22)
            bot.addView(t, lp(0, dp(42), 2, 4, 2, 0).also { it.weight = w })
        }
        pill("?123", 1.4f, th.keyAlt, th.text)
        pill(",", 1f, 0, th.text)
        pill("", 4f, th.keyAlt, th.text)
        pill(".", 1f, 0, th.text)
        val ea = p.getBoolean("enteraccent", true)
        pill("⏎", 1.4f, if (ea) th.accent else th.keyAlt, if (ea) th.onAccent else th.text)
        kb.addView(bot)
        card.addView(kb)

        val chips = LinearLayout(this)
        chips.setPadding(0, dp(18), 0, dp(4))
        val labels = listOf("A", "123", "😊", "@", "⧉")
        for (i in labels.indices) {
            val t = tv(labels[i], 18f, if (i == chip) Color.WHITE else TXT, true)
            t.gravity = Gravity.CENTER
            t.background = bg(if (i == chip) BLUE else CHIP, 18)
            t.setOnClickListener { chip = i; show(0) }
            chips.addView(t, lp(0, dp(56), 4, 0, 4, 0).also { it.weight = 1f })
        }
        card.addView(chips)
        pg.addView(card, lp(M, W, 0, 0, 0, 14))

        val opt = LinearLayout(this)
        opt.orientation = LinearLayout.VERTICAL
        val re = { show(0) }
        when (chip) {
            0 -> sw(opt, "flat", "ফ্ল্যাট কি (ব্যাকগ্রাউন্ড ছাড়া)", false, re)
            1 -> sw(opt, "hints", "কি-এর উপরে সংখ্যা/চিহ্ন হিন্ট", true, re)
            2 -> sw(opt, "sugg", "সাজেশন বার চালু", true, re)
            3 -> sw(opt, "enteraccent", "এন্টার কি রঙিন (অ্যাকসেন্ট)", true, re)
            else -> sw(opt, "clipon", "ক্লিপবোর্ড হিস্ট্রি", true, re)
        }
        pg.addView(opt, lp(M, W, 0, 0, 0, 10))

        plain(pg, "Key Gap and Font Size") {
            openSub("Key Gap and Font Size") { c ->
                seek(c, "keyh", 40, 80, 48, "কি-হাইট (dp)")
                seek(c, "gap", 1, 6, 2, "কি গ্যাপ (dp)")
                seek(c, "fscale", 80, 140, 100, "ফন্ট সাইজ (%)")
            }
        }
        plain(pg, "Suggestion Bar Style") {
            openSub("Suggestion Bar Style") { c ->
                sw(c, "sugg", "সাজেশন বার দেখান", true)
                sw(c, "autocorrect", "ইংরেজি অটো-কারেক্ট", true)
                sw(c, "mixvoice", "ভয়েসে বাংলা+ইংরেজি মিশ্র (ইংরেজি শব্দ ইংরেজি অক্ষরে)", true)
                sw(c, "nextword", "পরের শব্দের পূর্বাভাস (Next-word)", true)
                sw(c, "udict", "নিজে নিজে নতুন শব্দ শেখা (ব্যক্তিগত অভিধান)", true)
            }
        }
        return pg
    }

    // ---------- Themes (🎨) ----------
    private fun themesPage(): LinearLayout {
        val pg = page()
        pg.addView(tv("Themes", 30f, TXT, true).also { it.setPadding(dp(10), 0, 0, dp(10)) })
        val tileW = (resources.displayMetrics.widthPixels - dp(28) - dp(36)) / 3

        val mh = LinearLayout(this)
        mh.gravity = Gravity.CENTER_VERTICAL
        mh.addView(tv("My Themes", 22f).also { it.setPadding(dp(10), dp(16), 0, dp(16)) }, LinearLayout.LayoutParams(0, W, 1f))
        val imp = tv("Import", 16f, Color.WHITE)
        imp.setPadding(dp(26), dp(12), dp(26), dp(12))
        imp.background = bg(0xFF3A4472.toInt(), 22)
        imp.setOnClickListener { toast("Import শীঘ্রই আসছে") }
        mh.addView(imp)
        pg.addView(mh)

        val my = LinearLayout(this)
        val plus = FrameLayout(this)
        val pbox = FrameLayout(this)
        pbox.background = bg(0xFF18191D.toInt(), 22)
        val pl = tv("+", 30f, 0xFFB8C0FF.toInt()); pl.gravity = Gravity.CENTER
        pl.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(0xFF37383D.toInt()) }
        pbox.addView(pl, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        plus.addView(pbox, FrameLayout.LayoutParams(tileW, (tileW * 0.77f).toInt()))
        val pc = LinearLayout(this); pc.orientation = LinearLayout.VERTICAL; pc.gravity = Gravity.CENTER_HORIZONTAL
        pc.addView(plus); pc.addView(tv("Create Theme", 14f).also { it.setPadding(0, dp(8), 0, 0) })
        pc.setOnClickListener { createTheme() }
        my.addView(pc, lp(W, W, 6, 0, 6, 0))
        if (p.contains("c_bg")) my.addView(tile("custom", "My Theme", tileW), lp(W, W, 6, 0, 6, 0))
        pg.addView(my)

        pg.addView(tv("Platform Themes", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, listOf("light" to "Light", "dark" to "Dark", "navy" to "Navy"), tileW)
        pg.addView(tv("Exclusive", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, listOf("glass" to "Glass Dark", "bangla" to "Bangla-first", "neuL" to "Soft White", "neuD" to "Soft Black"), tileW)
        pg.addView(tv("Colors", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, Themes.colors.indices.map { "c$it" to "" }, tileW)
        pg.addView(tv("Gradients", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, Themes.gradients.indices.map { "g$it" to "" }, tileW)
        return pg
    }

    private fun grid(c: LinearLayout, items: List<Pair<String, String>>, tileW: Int) {
        for (chunk in items.chunked(3)) {
            val row = LinearLayout(this)
            for (it in chunk) row.addView(tile(it.first, it.second.ifEmpty { null }, tileW), lp(W, W, 6, 0, 6, 10))
            c.addView(row)
        }
    }

    private fun tile(id: String, label: String?, w: Int): View {
        val th = Themes.get(id, p)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val fr = FrameLayout(this)
        val box = FrameLayout(this)
        val g = th.grad
        if (g != null) {
            val gd = GradientDrawable(if (th.vert) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.TL_BR, g)
            gd.cornerRadius = dp(22).toFloat(); box.background = gd
        } else box.background = bg(th.bg, 22)
        val h = (w * 0.77f).toInt()
        val bar = View(this); bar.background = bg(th.key, 6)
        box.addView(bar, FrameLayout.LayoutParams((w * 0.5f).toInt(), (h * 0.15f).toInt(), Gravity.BOTTOM or Gravity.START).also {
            it.setMargins(dp(14), 0, 0, dp(14))
        })
        val ac = View(this); ac.background = bg(th.accent, 6)
        box.addView(ac, FrameLayout.LayoutParams((w * 0.14f).toInt(), (w * 0.14f).toInt(), Gravity.BOTTOM or Gravity.END).also {
            it.setMargins(0, 0, dp(14), dp(14))
        })
        fr.addView(box, FrameLayout.LayoutParams(w, h))
        val ck = tv("✓", 22f, Color.WHITE, true)
        ck.gravity = Gravity.CENTER
        ck.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(BLUE); it.setStroke(dp(2), Color.WHITE) }
        fr.addView(ck, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        ck.visibility = if ((p.getString("theme", "dark") ?: "dark") == id) View.VISIBLE else View.INVISIBLE
        checks.add(Pair(id, ck))
        fr.setOnClickListener {
            p.edit().putString("theme", id).apply()
            for (x in checks) x.second.visibility = if (x.first == id) View.VISIBLE else View.INVISIBLE
        }
        col.addView(fr)
        if (label != null) col.addView(tv(label, 14f).also { it.setPadding(0, dp(8), 0, 0) })
        return col
    }

    private fun createTheme() {
        val th = Themes.get(p.getString("theme", "dark") ?: "dark", p)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(20), dp(10), dp(20), dp(0))
        fun field(h: String, c: Int): EditText {
            val e = EditText(this)
            e.hint = h; e.setText(String.format("#%06X", c and 0xFFFFFF))
            l.addView(e); return e
        }
        val a = field(T("ব্যাকগ্রাউন্ড #RRGGBB"), th.bg)
        val k = field(T("কি রঙ #RRGGBB"), th.key)
        val c = field(T("অ্যাকসেন্ট #RRGGBB"), th.accent)
        AlertDialog.Builder(this).setTitle("Create Theme").setView(l)
            .setPositiveButton("Save") { _, _ ->
                try {
                    p.edit().putInt("c_bg", Color.parseColor(a.text.toString().trim()))
                        .putInt("c_key", Color.parseColor(k.text.toString().trim()))
                        .putInt("c_acc", Color.parseColor(c.text.toString().trim()))
                        .putString("theme", "custom").apply()
                    show(1)
                } catch (e: Exception) {
                    toast("রঙের কোড ঠিক নেই (যেমন #1A1A20)")
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- Settings (⚙) ----------
    private fun langPage() {
        openSub("Language") { c ->
            note(c, "অ্যাপের ভাষা (শুধু এই সেটিংস অ্যাপের লেখা বদলাবে, কিবোর্ড নয়)")
            radios(c, "uilang", "bn", listOf("bn" to "বাংলা", "en" to "English")) { langPage() }
            header(c, "Letters")
            item(c, "font", 0xFFF59E0B.toInt(), "Letter style", "ইংরেজি ও বাংলা অক্ষরের স্টাইল") { letterStylePage() }
        }
    }

    // ---------- letter style: English = styled Unicode letters, Bangla = key typeface ----------
    private fun letterStylePage() {
        openSub("Letter style", null) { c ->
            val en = p.getString("enstyle", "normal") ?: "normal"
            val bnS = p.getString("bnstyle", "normal") ?: "normal"
            header(c, "English letters")
            stylePreview(c, LetterStyle.apply(en, "Hello friend"), null)
            styleGrid(c, LetterStyle.en, en, { id -> LetterStyle.apply(id, "Hello") }, { null }) { id -> p.edit().putString("enstyle", id).apply(); letterStylePage() }
            header(c, "Bangla letters")
            stylePreview(c, "আমি তোমাকে ভালোবাসি", LetterStyle.bnTypeface(bnS))
            styleGrid(c, LetterStyle.bn, bnS, { "বাংলা" }, { id -> LetterStyle.bnTypeface(id) }) { id -> p.edit().putString("bnstyle", id).apply(); letterStylePage() }
            header(c, "সংখ্যা")
            val dg = p.getString("bndigits", "en") ?: "en"
            styleGrid(c, listOf("bn" to "বাংলা সংখ্যা", "en" to "English digits"), dg, { id -> if (id == "bn") "১২৩" else "123" }, { null }) { id -> p.edit().putString("bndigits", id).apply(); letterStylePage() }
            note(c, "English স্টাইল টাইপ করা লেখায়ও বসবে। Bangla স্টাইল কিবোর্ডের কি-এর লেখার চেহারা বদলায়। সংখ্যা: নম্বর প্যাডে বাংলা মোডে কোনটা আগে আসবে।")
        }
    }

    private fun stylePreview(c: LinearLayout, text: String, tf: Typeface?) {
        val v = tv(text, 24f)
        v.gravity = Gravity.CENTER
        tf?.let { v.typeface = it }
        v.setPadding(dp(16), dp(16), dp(16), dp(16))
        val g = bg(0xFF2B2C31.toInt(), 16); g.setStroke(dp(1), BLUE)
        v.background = g
        c.addView(v, lp(M, W, 0, 0, 0, 10))
    }

    private fun styleGrid(c: LinearLayout, opts: List<Pair<String, String>>, cur: String,
                          sample: (String) -> String, face: (String) -> Typeface?, pick: (String) -> Unit) {
        for (chunk in opts.chunked(2)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (o in chunk) {
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.setPadding(dp(14), dp(10), dp(14), dp(10))
                val g = bg(if (o.first == cur) 0xFF2F3A5C.toInt() else CARD, 14)
                if (o.first == cur) g.setStroke(dp(2), BLUE)
                cell.background = g
                val a = tv(sample(o.first), 19f)
                face(o.first)?.let { a.typeface = it }
                a.setSingleLine(true)
                cell.addView(a)
                cell.addView(tv(o.second, 11f, DIM))
                cell.setOnClickListener { pick(o.first) }
                row.addView(cell, lp(0, W, 0, 0, 8, 8).also { it.weight = 1f })
            }
            if (chunk.size == 1) row.addView(View(this), lp(0, W).also { it.weight = 1f })
            c.addView(row)
        }
    }

    private fun settingsPage(): LinearLayout {
        val pg = page()
        item(pg, "palette", 0xFFFF5C7A.toInt(), "Themes") { show(1) }
        item(pg, "sliders", 0xFFFFA928.toInt(), "Preferences") {
            openSub("Preferences") { c ->
                sw(c, "vibrate", "কি চাপলে ভাইব্রেশন", true)
                sw(c, "flat", "ফ্ল্যাট কি", false)
                sw(c, "hints", "কি হিন্ট (সংখ্যা/চিহ্ন)", true)
                sw(c, "enteraccent", "এন্টার কি রঙিন", true)
            }
        }
        item(pg, "pointer", 0xFFF59E0B.toInt(), "কি প্রেস সাউন্ড", "কি চাপলে শব্দ হবে") { keySoundPage() }
        item(pg, "kbd", 0xFF06B6D4.toInt(), "Keyboard size", "Height & bottom padding") { keySizePage() }
        item(pg, "pointer", 0xFFEF4444.toInt(), "Key tap", "Vibration & key pop-up") { keyTapPage() }
        item(pg, "font", 0xFF9B5CF6.toInt(), "Font Manager") {
            openSub("Font Manager") { c ->
                seek(c, "fscale", 80, 140, 100, "ফন্ট সাইজ (%)")
                note(c, "কাস্টম ফন্ট ইনস্টল সুবিধা এখনো নেই।")
            }
        }

        header(pg, "Keyboard")
        item(pg, "globe", 0xFF14B8A6.toInt(), "Language", if (uiEn()) "English" else "বাংলা") { langPage() }
        item(pg, "kbd", 0xFF3B82F6.toInt(), "Keyboard Layouts") {
            openSub("Keyboard Layouts") { c ->
                note(c, "বাংলা লেআউট")
                radios(c, "bnlayout", "classic", listOf("classic" to "ক্লাসিক (গ্রিড)", "phonetic" to "ফোনেটিক (অভ্র/প্রবাত স্টাইল)"))
            }
        }
        item(pg, "suggest", 0xFF6366F1.toInt(), "Suggestion Bar & Text Correction") {
            openSub("Suggestion Bar & Text Correction") { c ->
                sw(c, "sugg", "সাজেশন বার দেখান", true)
                sw(c, "autocorrect", "ইংরেজি অটো-কারেক্ট", true)
            }
        }
        item(pg, "book", 0xFFF472B6.toInt(), "Learning & Dictionaries") {
            openSub("Learning & Dictionaries") { c ->
                val n = (p.getString("recent", "") ?: "").split("\u0001").count { it.isNotEmpty() }
                val ud = try { java.io.File(filesDir, "udict.txt").let { f -> if (f.exists()) f.readLines().size else 0 } } catch (e: Exception) { 0 }
                note(c, "ব্যক্তিগত অভিধানে শেখা শব্দ: $ud (বাংলা ও ইংরেজি)\nশেখা (রিসেন্ট) শব্দ: $n\nবিল্ট-ইন ডিকশনারি: assets/bn_words.txt ও en_words.txt ফাইলে শব্দ যোগ করা যায়।")
                btn(c, "শেখা শব্দ মুছুন") { p.edit().remove("recent").remove("bigram").apply(); try { java.io.File(filesDir, "udict.txt").delete(); java.io.File(filesDir, "bigram.txt").delete() } catch (e: Exception) { }; toast("মুছে ফেলা হয়েছে"); show(tab) }
            }
        }
        item(pg, "clip", 0xFFFB7C3A.toInt(), "Clipboard") {
            openSub("Clipboard") { c ->
                sw(c, "clipon", "ক্লিপবোর্ড হিস্ট্রি চালু", true)
                val n = (p.getString("clips", "") ?: "").split("\u0001").count { it.isNotEmpty() }
                note(c, "সংরক্ষিত ক্লিপ: $n")
                btn(c, "ক্লিপবোর্ড হিস্ট্রি মুছুন") { p.edit().remove("clips").apply(); toast("মুছে ফেলা হয়েছে"); show(tab) }
            }
        }
        item(pg, "keymap", 0xFF7C3AED.toInt(), "Borno Phonetic Keymap") {
            openSub("Borno Phonetic Keymap") { c ->
                val t = tv(
                    T("স্বরবর্ণ: o=অ a=আ i=ই I/ee=ঈ u=উ U/oo=ঊ rri=ঋ e=এ oi=ঐ O=ও ou=ঔ\n" +
                    "ব্যঞ্জন: k=ক kh=খ g=গ gh=ঘ Ng=ঙ c=চ ch=ছ j=জ jh=ঝ NG=ঞ\n" +
                    "T=ট Th=ঠ D=ড Dh=ঢ N=ণ t=ত th=থ d=দ dh=ধ n=ন\n" +
                    "p=প f/ph=ফ b=ব v/bh=ভ m=ম z=য r=র l=ল sh=শ Sh=ষ s=স h=হ\n" +
                    "R=ড় Rh=ঢ় y=য় t``=ৎ ng=ং :=ঃ ^=ঁ\n" +
                    "যুক্তাক্ষর: kk=ক্ক, kkh=ক্ষ (ব্যঞ্জন পরপর লিখলে হসন্ত যুক্ত হয়)\n" +
                    "ফলা/রেফ: ky=ক্য, sw=স্ব (ব-ফলা), rr=র্ (korrmo=কর্ম), ngk=ঙ্ক, y একা=য়\n" +
                    "দীর্ঘ স্বর: aa=আ ii=ঈ uu=ঊ, স্বরের পর o=ও (dao=দাও)\n" +
                    "উদাহরণ: ami=আমি, bangla=বাংলা, bhalO=ভালো, valo=ভালো"), 16f
                )
                t.setLineSpacing(0f, 1.3f)
                t.setPadding(dp(16), dp(16), dp(16), dp(16)); t.background = bg(CARD, 16)
                c.addView(t)
            }
        }
        item(pg, "more", 0xFF64748B.toInt(), "Advanced") {
            openSub("Advanced") { c ->
                item(c, "more", 0xFFEF4444.toInt(), "Block words", "Never suggest or save these words") { blockWordsPage() }
                btn(c, "সব সেটিংস রিসেট করুন") { p.edit().clear().apply(); toast("রিসেট হয়েছে"); show(tab) }
            }
        }

        header(pg, "Gestures")
        item(pg, "swap", 0xFF0EA5E9.toInt(), "Smart Gestures", "শীঘ্রই আসছে") { toast("এখনো তৈরি হয়নি") }
        item(pg, "swirl", 0xFFD946EF.toInt(), "Gesture Typing", "শীঘ্রই আসছে") { toast("এখনো তৈরি হয়নি") }

        header(pg, "App")
        item(pg, "power|1", 0xFF22C55E.toInt(), "কিবোর্ড চালু করুন", "সিস্টেম সেটিংসে অন করুন") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        item(pg, "pointer|2", 0xFF10B981.toInt(), "এই কিবোর্ড বেছে নিন", "ইনপুট মেথড বদলান") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        item(pg, "pencil", 0xFF475569.toInt(), "টেস্ট করুন") {
            openSub("টেস্ট করুন") { c ->
                val et = EditText(this)
                et.hint = T("এখানে টাইপ করে দেখুন"); et.setTextColor(TXT); et.setHintTextColor(DIM)
                c.addView(et)
            }
        }
        item(pg, "globe", 0xFF3B82F6.toInt(), "আপডেট চেক করুন", "বর্তমান ভার্সন " + BuildConfig.VERSION_NAME) {
            toast("চেক করা হচ্ছে…"); checkUpdate(true)
        }
        item(pg, "more", 0xFF6366F1.toInt(), "About") {
            openSub("About") { c ->
                val t = tv("Made by Foridul Islam\n\nfab27121995@gmail.com\n\nVersion " + BuildConfig.VERSION_NAME, 18f)
                t.setLineSpacing(0f, 1.3f)
                t.setPadding(dp(20), dp(20), dp(20), dp(20)); t.background = bg(CARD, 16)
                t.setTextIsSelectable(true)
                c.addView(t)
            }
        }
        return pg
    }
}
