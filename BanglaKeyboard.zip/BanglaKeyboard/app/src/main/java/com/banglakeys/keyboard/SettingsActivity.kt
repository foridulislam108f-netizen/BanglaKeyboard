package com.banglakeys.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun label(t: String) {
            val v = TextView(this)
            v.text = t; v.textSize = 16f; v.setTypeface(null, Typeface.BOLD)
            v.setPadding(0, pad, 0, pad / 2)
            col.addView(v)
        }
        fun btn(t: String, f: () -> Unit) {
            val v = Button(this)
            v.text = t; v.setOnClickListener { f() }
            col.addView(v)
        }
        fun radios(key: String, def: String, opts: List<Pair<String, String>>) {
            val g = RadioGroup(this)
            for (o in opts) {
                val r = RadioButton(this)
                r.text = o.second; r.id = View.generateViewId(); r.tag = o.first
                r.isChecked = p.getString(key, def) == o.first
                g.addView(r)
            }
            g.setOnCheckedChangeListener { grp, id ->
                val v = grp.findViewById<View>(id)
                if (v != null) p.edit().putString(key, v.tag as String).apply()
            }
            col.addView(g)
        }
        fun sw(key: String, t: String, def: Boolean) {
            val s = Switch(this)
            s.text = t; s.isChecked = p.getBoolean(key, def)
            s.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
            col.addView(s)
        }

        label("বাংলা কিবোর্ড সেটআপ")
        btn("১) কিবোর্ড চালু করুন") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("২) এই কিবোর্ড বেছে নিন") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }

        label("বাংলা লেআউট")
        radios("bnlayout", "classic", listOf("classic" to "ক্লাসিক (স্ক্রিনশটের মত)", "phonetic" to "ফোনেটিক (অভ্র/প্রবাত স্টাইল)"))

        label("থিম")
        radios("theme", "dark", listOf(
            "dark" to "ডার্ক (ডিফল্ট)", "glass" to "Glass Dark",
            "light" to "Clean Light", "bangla" to "Bangla-first (বড় অক্ষর)"
        ))

        label("কি-হাইট")
        val sb = SeekBar(this)
        sb.max = 40
        sb.progress = p.getInt("keyh", 52) - 40
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("keyh", v + 40).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)

        label("অন্যান্য")
        sw("autocorrect", "ইংরেজি অটো-কারেক্ট", true)
        sw("vibrate", "কি চাপলে ভাইব্রেশন", true)

        label("টেস্ট করুন")
        val et = EditText(this)
        et.hint = "এখানে টাইপ করে দেখুন"
        col.addView(et)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }
}
