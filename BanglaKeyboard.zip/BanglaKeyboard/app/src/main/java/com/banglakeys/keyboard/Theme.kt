package com.banglakeys.keyboard

import android.content.SharedPreferences
import android.graphics.Color

class Theme(
    val bg: Int, val key: Int, val keyAlt: Int, val text: Int, val dim: Int,
    val accent: Int, val radius: Int, val scale: Float,
    val grad: IntArray? = null, val stroke: Int = 0
) {
    val onAccent: Int get() = if (Color.luminance(accent) > 0.5f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
}

class P(val bg: Int, val key: Int, val acc: Int)

object Themes {
    private fun p(bg: Long, key: Long, acc: Long) = P(bg.toInt(), key.toInt(), acc.toInt())

    val colors = listOf(
        p(0xFFE9EEF1, 0xFFFFFFFF, 0xFF80C4B7), p(0xFFE6E8EE, 0xFFFFFFFF, 0xFF3B6FE0),
        p(0xFFDEDEDF, 0xFFFFFFFF, 0xFFC8C8C8), p(0xFFCDD0D8, 0xFFFFFFFF, 0xFF2F6FF5),
        p(0xFF263038, 0xFF424A52, 0xFF66AFA6), p(0xFF25282C, 0xFF454A4F, 0xFF6A95E0),
        p(0xFF000000, 0xFF14141A, 0xFF6C97E0), p(0xFF1D1D1B, 0xFF404040, 0xFF4A66E8),
        p(0xFF12161D, 0xFF1E222C, 0xFF7066D8), p(0xFF000000, 0xFF1C1C1C, 0xFF5A5A5A),
        p(0xFF000000, 0xFF1C1C1C, 0xFFFFFF4D), p(0xFF0F0F26, 0xFF25264C, 0xFFB02FB0),
        p(0xFF111111, 0xFF25396B, 0xFF52717F), p(0xFF2F3438, 0xFF3E3E4E, 0xFF8A8AA8),
        p(0xFF3A4636, 0xFF56694B, 0xFFC9A55A), p(0xFF352739, 0xFF4A3650, 0xFFB57CC6),
        p(0xFF404040, 0xFF585858, 0xFF9A9A9A), p(0xFF5A9E50, 0xFF7CC070, 0xFF2E6B28)
    )

    private fun blend(a: Int, b: Int, t: Float): Int {
        fun m(x: Int, y: Int) = (x + (y - x) * t).toInt()
        return Color.rgb(m(Color.red(a), Color.red(b)), m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b)))
    }

    fun make(bg: Int, key: Int, acc: Int): Theme {
        val light = Color.luminance(bg) > 0.5f
        val text = if (light) 0xFF1B1B1F.toInt() else 0xFFEDEAF5.toInt()
        return Theme(bg, key, blend(key, text, 0.14f), text, blend(bg, text, 0.55f), acc, 12, 1f)
    }

    fun get(n: String, sp: SharedPreferences? = null): Theme {
        if (n.startsWith("c")) {
            val i = n.substring(1).toIntOrNull()
            if (i != null && i in colors.indices) { val c = colors[i]; return make(c.bg, c.key, c.acc) }
        }
        if (n == "custom" && sp != null) {
            return make(sp.getInt("c_bg", 0xFF1A1A20.toInt()), sp.getInt("c_key", 0xFF2B2B33.toInt()), sp.getInt("c_acc", 0xFFB4A8FF.toInt()))
        }
        return when (n) {
            "glass" -> Theme(0xFF0F1030.toInt(), 0x2EFFFFFF, 0x4DFFFFFF, 0xFFF2EEFF.toInt(), 0xFFA9A5C8.toInt(),
                0xFF7CF7FF.toInt(), 14, 1f, intArrayOf(0xFF0F1030.toInt(), 0xFF2A1450.toInt()), 0x33FFFFFF)
            "light" -> Theme(0xFFE8EAF0.toInt(), 0xFFFFFFFF.toInt(), 0xFFC9CED9.toInt(), 0xFF1B1B1F.toInt(),
                0xFF8A8F99.toInt(), 0xFF1E88E5.toInt(), 10, 1f)
            "navy" -> make(0xFF1B2335.toInt(), 0xFF2F3E63.toInt(), 0xFF4F7CF5.toInt())
            "bangla" -> Theme(0xFF0E1317.toInt(), 0xFF1E262E.toInt(), 0xFF2C3946.toInt(), 0xFFFFFFFF.toInt(),
                0xFF7E8A96.toInt(), 0xFF2ECC71.toInt(), 12, 1.2f)
            else -> Theme(0xFF1A1A20.toInt(), 0xFF2B2B33.toInt(), 0xFF3A3A4D.toInt(), 0xFFE6E1F5.toInt(),
                0xFF7C7A88.toInt(), 0xFFB4A8FF.toInt(), 12, 1f)
        }
    }
}
