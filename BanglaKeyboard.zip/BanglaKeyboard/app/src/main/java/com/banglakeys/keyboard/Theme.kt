package com.banglakeys.keyboard

class Theme(
    val bg: Int, val key: Int, val keyAlt: Int, val text: Int, val dim: Int,
    val accent: Int, val radius: Int, val scale: Float,
    val grad: IntArray? = null, val stroke: Int = 0
)

object Themes {
    fun get(n: String): Theme = when (n) {
        "glass" -> Theme(0xFF0F1030.toInt(), 0x2EFFFFFF, 0x4DFFFFFF, 0xFFF2EEFF.toInt(), 0xFFA9A5C8.toInt(),
            0xFF7CF7FF.toInt(), 14, 1f, intArrayOf(0xFF0F1030.toInt(), 0xFF2A1450.toInt()), 0x33FFFFFF)
        "light" -> Theme(0xFFE8EAF0.toInt(), 0xFFFFFFFF.toInt(), 0xFFC9CED9.toInt(), 0xFF1B1B1F.toInt(),
            0xFF8A8F99.toInt(), 0xFF1E88E5.toInt(), 10, 1f)
        "bangla" -> Theme(0xFF0E1317.toInt(), 0xFF1E262E.toInt(), 0xFF2C3946.toInt(), 0xFFFFFFFF.toInt(),
            0xFF7E8A96.toInt(), 0xFF2ECC71.toInt(), 12, 1.2f)
        else -> Theme(0xFF1A1A20.toInt(), 0xFF2B2B33.toInt(), 0xFF3A3A4D.toInt(), 0xFFE6E1F5.toInt(),
            0xFF7C7A88.toInt(), 0xFFB4A8FF.toInt(), 12, 1f)
    }
}
