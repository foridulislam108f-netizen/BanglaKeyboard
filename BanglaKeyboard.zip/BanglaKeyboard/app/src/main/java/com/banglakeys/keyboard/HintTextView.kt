package com.banglakeys.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.widget.TextView

/** TextView that draws a small hint (digit/symbol) in the top-right corner. */
open class HintTextView(c: Context) : TextView(c) {
    var hintText: String? = null
    var hintColor = 0
    var hintSize = 0f
    var hintBold = false
    var hintBaseline = -1f   // px from top; < 0 = default position
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun hasOverlappingRendering() = false   // press-fade without an off-screen layer (faster)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = hintText ?: return
        paint.color = hintColor
        paint.textSize = hintSize
        paint.isFakeBoldText = hintBold
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText(s, width - hintSize * 0.35f, if (hintBaseline >= 0f) hintBaseline else hintSize * 1.3f, paint)
    }
}
