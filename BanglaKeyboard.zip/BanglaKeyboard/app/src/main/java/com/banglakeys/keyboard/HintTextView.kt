package com.banglakeys.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.widget.TextView

/** TextView that draws a small hint (digit/symbol) in the top-right corner. */
class HintTextView(c: Context) : TextView(c) {
    var hintText: String? = null
    var hintColor = 0
    var hintSize = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = hintText ?: return
        paint.color = hintColor
        paint.textSize = hintSize
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText(s, width - hintSize * 0.35f, hintSize * 1.3f, paint)
    }
}
