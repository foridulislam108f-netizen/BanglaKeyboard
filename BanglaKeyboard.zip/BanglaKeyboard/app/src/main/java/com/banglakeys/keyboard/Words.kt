package com.banglakeys.keyboard

object Words {
    fun load(ctx: android.content.Context) {
        try {
            val b = ctx.assets.open("bn_words.txt").bufferedReader().readText().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val e = ctx.assets.open("en_words.txt").bufferedReader().readText().split(Regex("\\s+")).filter { it.isNotEmpty() }
            bn = (b + bn).distinct(); en = (e + en).distinct(); enSet = en.toSet()
        } catch (ex: Exception) { }
    }

    var bn: List<String> = ("আমি আমার আমাকে আমরা আমাদের আপনি আপনার আপনাকে তুমি তোমার তোমাকে সে তার তাকে তারা ওরা এটা ওটা এখানে সেখানে " +
        "কেমন আছো আছেন আছি ভালো খারাপ ধন্যবাদ স্বাগতম বাংলা বাংলাদেশ ঢাকা চট্টগ্রাম কি কী কেন কোথায় কখন কিভাবে কত কোন " +
        "হ্যাঁ না এবং কিন্তু অথবা যদি তাহলে কারণ আজ আজকে কাল গতকাল এখন পরে আগে সময় কাজ বাড়ি স্কুল কলেজ অফিস খাবার পানি টাকা " +
        "বন্ধু পরিবার মা বাবা ভাই বোন শুভ সকাল দুপুর বিকাল সন্ধ্যা রাত দিন সুন্দর ভালোবাসি ভালোবাসা দাওয়াত অনেক একটু আবার " +
        "করছি করব করেছি করো করেন যাচ্ছি যাব যাও আসছি আসব এসো দেখি দেখো বলো বলেন বলছি খাচ্ছি খেয়েছি পড়ছি লিখছি শুনছি " +
        "জন্মদিন শুভেচ্ছা অভিনন্দন ঈদ মোবারক রমজান সালাম ওয়ালাইকুম আলহামদুলিল্লাহ ইনশাআল্লাহ মাফ দুঃখিত প্রয়োজন সমস্যা সাহায্য " +
        "মোবাইল ফোন নম্বর ইন্টারনেট অ্যাপ কিবোর্ড ভিডিও গান ছবি খবর খেলা পড়াশোনা পরীক্ষা ফলাফল চাকরি ব্যবসা বাজার রাস্তা গাড়ি বাস ট্রেন").split(" ")

    var en: List<String> = ("the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all " +
        "would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could " +
        "them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us " +
        "hello hi thanks thank please sorry welcome okay yes where why today tomorrow yesterday tonight morning evening night friend family mother father brother sister " +
        "home school office food water money phone message call send love happy birthday congratulations great nice beautiful really very much many little again always never " +
        "maybe sure right wrong problem help need going coming doing having being should before between through during without another everything something " +
        "someone anything nothing together important different example question answer language keyboard bangla english typing").split(" ")

    var enSet: Set<String> = en.toSet()

    /** starter next-word suggestions (the keyboard also learns your own pairs) */
    val seed: Map<String, List<String>> = mapOf(
        "আমি" to listOf("ভালো", "তোমাকে", "আজ"), "আমার" to listOf("নাম", "কাছে", "মনে"),
        "আপনি" to listOf("কেমন", "কি", "কোথায়"), "আপনার" to listOf("নাম", "সাথে", "জন্য"),
        "তুমি" to listOf("কেমন", "কোথায়", "কি"), "তোমার" to listOf("নাম", "সাথে", "জন্য"),
        "কেমন" to listOf("আছো", "আছেন", "লাগছে"), "কি" to listOf("করছো", "খবর", "হয়েছে"),
        "কী" to listOf("করছো", "খবর", "হয়েছে"), "কিভাবে" to listOf("করব", "যাব", "বুঝব"),
        "ধন্যবাদ" to listOf("আপনাকে", "অনেক", "ভাই"), "অনেক" to listOf("ধন্যবাদ", "ভালো", "সুন্দর"),
        "শুভ" to listOf("সকাল", "রাত্রি", "জন্মদিন"), "ঈদ" to listOf("মোবারক", "মুবারক", "শুভেচ্ছা"),
        "জন্মদিনের" to listOf("শুভেচ্ছা", "অনেক", "অভিনন্দন"), "ইনশাআল্লাহ" to listOf("আমি", "কাল", "হবে"),
        "আজ" to listOf("আমি", "কি", "বিকালে"), "কাল" to listOf("আমি", "দেখা", "সকালে"),
        "এখন" to listOf("আমি", "কোথায়", "কি"), "আসসালামু" to listOf("আলাইকুম"),
        "ওয়ালাইকুম" to listOf("আসসালাম"), "ভালোবাসি" to listOf("তোমাকে", "অনেক"),
        "i" to listOf("am", "will", "love"), "you" to listOf("are", "can", "have"),
        "how" to listOf("are", "to", "do"), "what" to listOf("is", "are", "do"),
        "thank" to listOf("you"), "thanks" to listOf("for", "a", "so"), "good" to listOf("morning", "night", "luck"),
        "see" to listOf("you", "the", "it"), "i'm" to listOf("not", "going", "fine"), "it" to listOf("is", "was", "will"),
        "the" to listOf("same", "best", "first"), "can" to listOf("you", "i", "we"), "will" to listOf("be", "do", "you"),
        "please" to listOf("send", "call", "let"), "hello" to listOf("sir", "there", "how"),
        "happy" to listOf("birthday", "new", "eid"), "let" to listOf("me", "us", "you"),
        "are" to listOf("you", "we", "they"), "is" to listOf("it", "the", "there"), "do" to listOf("you", "not", "it")
    )

    fun dist(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    fun fix(w: String): String? {
        for (c in en) {
            if (c.length in (w.length - 1)..(w.length + 1) && c[0] == w[0] && dist(w, c) == 1) return c
        }
        return null
    }

    val emoji = ("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😒 😞 😔 😢 😭 😤 😡 🤯 😱 😴 🤔 🙄 😬 🤗 🤭 🤫 😷 🤒 " +
        "👍 👎 👌 ✌️ 🤞 🤝 🙏 👏 🙌 💪 👋 ☝️ 👉 👈 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💕 💖 💯 🔥 ✨ ⭐ 🌟 🎉 🎂 🎁 🌹 🌸 🌙 ☀️ 🌈 " +
        "🍎 🍌 🍕 🍔 ☕ 🍵 🍚 🍗 ⚽ 🏏 🎮 🎵 📱 💻 📷 🚗 ✈️ 🏠 ✅ ❌ ⚠️ ❓ ❗").split(" ")

    val stickers = ("🎉 ❤️ 🔥 👍 🙏 😂 😍 🥳 💯 ✨ 🌹 🎂 😭 😎 🤝 💪 🌙 ☀️ 🕌 🇧🇩").split(" ")

    val textStickers = listOf(
        "ধন্যবাদ 🙏", "শুভ সকাল ☀️", "শুভ রাত্রি 🌙", "জন্মদিনের শুভেচ্ছা 🎂",
        "ঈদ মোবারক 🌙", "ভালোবাসি ❤️", "অভিনন্দন 🎉", "আসসালামু আলাইকুম"
    )
}
