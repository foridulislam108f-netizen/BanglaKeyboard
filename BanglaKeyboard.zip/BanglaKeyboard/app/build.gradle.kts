plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// sherpa-onnx (offline speech) is optional: when libs/sherpa-onnx.aar exists the real engine is compiled, otherwise a stub
val hasSherpa = file("libs/sherpa-onnx.aar").exists()

android {
    namespace = "com.banglakeys.keyboard"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.banglakeys.keyboard"
        minSdk = 24
        targetSdk = 34
        // CI bumps the version on every build so a new APK installs over the old one
        val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = run
        versionName = "1.$run"
        if (hasSherpa) ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }   // keep the APK small
    }
    sourceSets.getByName("main").java.srcDir(if (hasSherpa) "src/sherpa/java" else "src/stub/java")
    signingConfigs {
        // fixed key (committed in repo) -> every build has the SAME signature -> update-in-place, no uninstall
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            // same fixed key as before -> installs over the old APK; release build = much faster than a debug build
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    if (hasSherpa) implementation(files("libs/sherpa-onnx.aar"))
}
