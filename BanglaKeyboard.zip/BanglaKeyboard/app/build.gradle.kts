plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.banglakeys.keyboard"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.banglakeys.keyboard"
        minSdk = 24
        targetSdk = 34
        // CI bumps the version on every build so a new APK installs over the old one
        val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = run   // must keep going up on every build
        versionName = "3.${run}"   // 3 = major (change by hand when you want); the number after the dot grows by itself on every GitHub build
        // GitHub repo (owner/name) for the in-app update check; filled automatically by GitHub Actions
        buildConfigField("String", "GH_REPO", "\"${System.getenv("GITHUB_REPOSITORY") ?: ""}\"")
    }
    signingConfigs {
        // fixed key (committed in repo) -> every build has the SAME signature -> update-in-place, no uninstall
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
}
