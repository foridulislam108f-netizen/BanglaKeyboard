# Bangla Keyboard (Android IME)
Build: push to GitHub -> Actions -> "Build APK" -> download artifact BanglaKeyboard-APK (app-debug.apk).
Or Android Studio: open folder, Run.
After install: open app -> (1) enable keyboard -> (2) choose keyboard.
Phonetic tips: ami=আমি, bangla=বাংলা, capital O = ো (bhalO), T/Th/D/Dh = ট/ঠ/ড/ঢ, ng=ং, Ng=ঙ, t``=ৎ.
